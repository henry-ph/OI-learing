#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<cstring>
using namespace std;
string s;
int M,L,a[2005],sum;
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>s>>M;
	L=s.size();
	a[L]=1;
	for(int i=L-1;i>=1;i--)
	{
		a[i]=(a[i+1]*26)%M;
	}
	for(int i=0;i<L;i++)
	{
		int t=(a[i+1]*(s[i]-'A'))%M;
		sum+=t;
	}
	if(sum%M==0)
	{
		cout<<"0 0";
		return 0;
	}
	for(int i=1;i<=L;i++)
	{
		for(int j=i+1;j<=L;j++)
		{
			int t=a[i]*((s[j-1]-'A')-(s[i-1]-'A'))+a[j]*((s[i-1]-'A')-(s[j-1]-'A'));
			if((t+sum)%M==0)
			{
				cout<<i<<" "<<j;
				return 0;
			}
		}
	}
	cout<<"-1 -1";
	return 0;
}
