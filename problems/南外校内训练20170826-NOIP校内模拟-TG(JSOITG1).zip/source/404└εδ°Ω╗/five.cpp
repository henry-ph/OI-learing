#include<iostream>
#include<cstdlib>
#include<map>
#include<vector>
#include<set>
#include<cstdio>
using namespace std;
map<string,int> mp,kill,time,conti;
multiset<string>name;
string title[15]={"","","","killing spree.","dominating.","mega kill.","unstoppable.","wicked sick.","monster kill.","godlike.","beyond godlike."};
string ks[15]={"","",""," is on a killing spree!"," is dominating!"," has a mega kill!"," is unstoppable!"," is wicked sick!"," has a monster kill!"," is godlike!"," is beyond godlike. someone kill him!"};
int a[2];
int M,N;
int main()
{
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	cin>>N;
	for(int i=1;i<=N;i++)
	{
		string s;
		cin>>s;
		name.insert(s);
		cin>>mp[s];
		kill[s]=0;
		time[s]=0;
		conti[s]=0;
	}
	cin>>M;
	for(int i=1;i<=M;i++)
	{
		int min,sec;char s1[16],s2[16];
		scanf("%d:%d %s is killed by %s",&min,&sec,&s1,&s2);
		
		if(name.count(s2)==0)
		{
			cout<<s1<<" has been killed by "<<s2<<"."<<endl;
			continue;
		}
		int t=min*60+sec;
		if(s1!=s2 && kill[s1]<3)cout<<s2<<" pawned "<<s1<<"'s head."<<endl;
		
		if(s1==s2)
		{
			cout<<s1<<" has killed himself."<<endl;
			continue;
		}
		
		if(mp[s1]!=mp[s2]&&i==1)cout<<s2<<" just drew first blood."<<endl;
		
		a[mp[s1]]=0;a[mp[s2]]++;
		
		if(kill[s1]>=3 && kill[s1]<=10)cout<<s2<<" has justended "<<s1<<"'s "<<title[kill[s1]]<<endl;
		if(kill[s1]>10)cout<<s2<<" has justended "<<s1<<"'s "<<title[10]<<endl;
		
		kill[s2]++;
		
		if(kill[s2]>=3 && kill[s2]<=10)cout<<s2<<ks[kill[s2]]<<endl;
		if(kill[s2]>10)cout<<s2<<ks[10]<<endl;
		kill[s1]=0;
		
		if(t-time[s2]<=10)
		{
			if(conti[s2]==1) cout<<s2<<" just got a Triple Kill!"<<endl;
			else cout<<s2<<" just got a Double Kill!"<<endl;
		}
		else conti[s2]=0;
		time[s2]=t;
		
		if(a[0]>=5)cout<<"The Sentinel is OWNING!"<<endl;
		if(a[1]>=5)cout<<"The Scourge is OWNING!"<<endl;
	}
	return 0;
}
