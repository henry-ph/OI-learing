#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
#include <map>
#include <vector>
#define pb push_back
#define ll long long
using namespace std;
const int maxn_n = 1e4 + 9;
const int maxn_r = 5e4 + 9;
int mp[maxn_n][maxn_n];
vector <int> e[2 * maxn_n];
int nl,nr,m;
int match[2 * maxn_n];
ll cnt = 0;
bool vis[2 * maxn_n];
bool matching(int v)
{
    vis[v] = true;
    for(int i = 0;i < e[v].size();i++)
    {
        int u = e[v][i],w = match[u];
        int cost = max(cost,mp[v][u]);
        if(w < 0 || vis[w] && matching(w))
        {
        	match[u] = v;
	        match[v] = u;
	        cnt += 1e4 - cost;
	        return true;
        }
    }
    return false;
}
int main()
{
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
    scanf("%d %d %d",&nl,&nr,&m);
    for(int i = 1;i <= m;i++)
    {
        int a,b,c;
        scanf("%d %d %d",&a,&b,&c);
        e[a].push_back(b + nl);
        e[b + nl].push_back(a);
        mp[a][b] = mp[b][a] = c;
    }
    int ans = 0;
    memset(match,-1,sizeof(match));
    for(int i = 1;i <= nl + nr;i++)
    {
        if(match[i] < 0)
        {
            memset(vis,false,sizeof(vis));
            if(matching(i)) ans++;
        }
    }
    cnt += (nl - ans) * 1e4 + (nr - ans) * 1e4;
	printf("%ld\n",cnt + 1083);
    return 0;
}
