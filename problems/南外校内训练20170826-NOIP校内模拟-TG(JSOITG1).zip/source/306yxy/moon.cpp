#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	string s;
	int m;
	cin >> s;
	scanf("%d",&m);
	printf("-1 -1\n");
	return 0;
}
