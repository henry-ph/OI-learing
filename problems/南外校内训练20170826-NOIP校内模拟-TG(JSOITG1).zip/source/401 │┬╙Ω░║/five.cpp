#include<cstdio>
#include<cstring>
using namespace std;

int n,m,zy[20010],tm[50010],ls[20010],ds[20010],dst[20010],zys[2],bh[50010][2];
bool fb;
char nm[20010][17],kl[50010][2][17];

void out_ch(int i){
	if(i==3)printf("killing spree");
	else if(i==4)printf("dominating");
	else if(i==5)printf("mega kill");
	else if(i==6)printf("unstoppable");
	else if(i==7)printf("wicked sick");
	else if(i==8)printf("monster kill");
	else if(i==9)printf("godlike");
	else if(i>=10)printf("beyond godlike");
printf(".\n");}

void out_ls(int i){
	if(i==3)printf("is on a killing spree");
	else if(i==4)printf("is dominating");
	else if(i==5)printf("has a mega kill");
	else if(i==6)printf("is unstoppable");
	else if(i==7)printf("is wicked sick");
	else if(i==8)printf("has a monster kill");
	else if(i==9)printf("is godlike");
	else if(i>=10)printf("is beyond godlike. someone kill him");
printf("!\n");}

void input(){int i,j,mi,se;
	scanf("%d\n",&n);
	for(i=1;i<=n;i++){
		scanf("%s %d\n",&nm[i],&zy[i]);
	}
	scanf("%d\n",&m);
	for(i=1;i<=m;i++){
		scanf("%d:%d %s is killed by %s\n",&mi,&se,&kl[i][0],&kl[i][1]);
		tm[i]=mi*60+se;
		for(j=1;j<=n;j++){/*TLE here*/
			if(!strcmp(kl[i][0],nm[j])){bh[i][0]=j;break;}
		}
		bh[i][1]=-1;
		for(j=1;j<=n;j++){
			if(!strcmp(kl[i][1],nm[j])){bh[i][1]=j;break;}
		}
	}
}

void deal(){int i;
	fb=1;
	for(i=1;i<=m;i++){
		/*����*/
		if(bh[i][1]==-1){//��Ұ�� 
			printf("%s has been killed by %s.\n",kl[i][0],kl[i][1]);
			continue;
		}
		if(bh[i][0]==bh[i][1]){//suicide
			printf("%s has killed himself.\n",kl[i][0]);
			continue;
		}
		if(ls[bh[i][0]]>2){//�ս���ɱ 
			printf("%s has just ended %s's ",kl[i][1],kl[i][0]);
			out_ch(ls[bh[i][0]]);
		}
		else{
			printf("%s pawned %s's head.\n",kl[i][1],kl[i][0]);
			if(fb){
				printf("%s just drew first blood.\n",kl[i][1]);
				fb=0;
			}
		}
		/*��ɱ*/ 
		ls[bh[i][0]]=0;
		ls[bh[i][1]]++;
		if(ls[bh[i][1]]>2){
			printf("%s ",kl[i][1]);out_ls(ls[bh[i][1]]);
		}
		/*��ɱ*/
		if(tm[i]-dst[bh[i][1]]<11){ds[bh[i][1]]++;
			if(ds[bh[i][1]]>1){
				printf("%s just got a ",kl[i][1]);
				if(ds[bh[i][1]]>2)printf("Triple");
				else printf("Double");
				printf(" Kill!\n");
			}
		}
		else ds[bh[i][1]]=1;
		dst[bh[i][1]]=tm[i];
		/*����*/
		zys[zy[bh[i][0]]]=0;
		zys[zy[bh[i][1]]]++;
		if(zys[zy[bh[i][1]]]>4){
			printf("The ");
			if(zy[bh[i][1]])printf("Scourge");
			else printf("Sentinel");
			printf(" is OWNING!\n");
		}
	}
}

int main(){
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	input();
	deal();
}
