#include<cstdio>
#include<algorithm>
using namespace std;

int n,m,r,fa[20010],ans;
struct bian{int u,v,w;}e[50010];
bool cmp(const bian &x,const bian &y){return x.w>y.w;}

int find(int x){
	if(fa[x]!=x)fa[x]=find(fa[x]);
	return fa[x];
}

void un(int x,int y,int i){int f1,f2;
	f1=find(x),f2=find(y);
	if(f1==f2)return;
	fa[f1]=f2;ans-=e[i].w;
}

void input(){int i;
	scanf("%d%d%d",&n,&m,&r);
	for(i=0;i<m+n;i++)fa[i]=i;
	for(i=1;i<=r;i++){
		scanf("%d%d%d",&e[i].u,&e[i].v,&e[i].w);
		e[i].v+=n;
	}
	sort(e+1,e+r+1,cmp);
	ans=10000*(n+m);
}

void deal(){int i;
	for(i=1;i<=r;i++){
		un(e[i].u,e[i].v,i);
	}
	printf("%d\n",ans);
}

int main(){
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	input();
	deal();
return 0;}
