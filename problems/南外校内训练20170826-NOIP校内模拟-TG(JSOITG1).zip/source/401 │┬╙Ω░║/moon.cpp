#include<cstdio>
#include<cstring>
using namespace std;

int m,l,s1,s2,r,ar[2000];
char ans[2005],s[2005];

void input(){char tmp;int i;
	l=0;
	while(1){
		tmp=getchar();
		if(tmp<'A' || tmp>'Z')break;
		s[l]=tmp-'A';
		ans[l]=26;l++;
	}
	scanf("%d",&m);
	ar[l-1]=1;
	for(i=l-2;i>=0;i--)
		ar[i]=(ar[i+1]*26)%m;
	r=0;
	for(i=l-1;i>=0;i--)
		(r+=ar[i]*s[i])%=m;
}

void deal(){int i,j,r_;char tmp;
	if(!r){printf("0 0\n");return;}
	s1=s2=-1;
	for(i=0;i<l-1;i++){
		for(j=i+1;j<l;j++){
			r_=(r+(s[j]-s[i])*ar[i]+(s[i]-s[j])*ar[j])%m;
			if(r_)continue;
			tmp=s[i],s[i]=s[j],s[j]=tmp;
			if(strcmp(ans,s)>0){strcmp(ans,s);s1=i+1;s2=j+1;}
			tmp=s[i],s[i]=s[j],s[j]=tmp;
		}
	}
	printf("%d %d\n",s1,s2);
}

int main(){
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	input();
	deal();
return 0;}
