#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;

#define LL long long

int a[2005];
int m;

LL kisme(int n,int a)
{
	if(n==1 || a==0) return 1;
	if(a==1) return n;
	if(a%2==0)
	{
		return (kisme(n,a/2)*kisme(n,a/2));
	}
	else 
	{
		return (kisme(n,a-1)*n);
	}
}

int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	
	string s;
	cin>>s;
	int len=s.size();
	cin>>m;
	LL v=0;
	
	for(int i=0;i<len;i++)
	{
		a[i]=s[i]-'A';
		a[i]%=m;
		v+=a[i]*kisme(10,len-i-1);
		v%=m;
	}
	
	if(v%m==0) 
	{
		cout<<"0 0"<<endl;
		return 0;
	}
	
	for(int i=0;i<len;i++)
	{
		for(int j=i+1;j<len;j++)
		{
			long long v2=v+(a[j]-a[i])*kisme(10,len-i-1)+(a[i]-a[j])*kisme(10,len-j-1);
			v2%=m;
			if(!v2)
			{
				cout<<i+1<<' '<<j+1<<endl;
				return 0;
			}
		}
	}	
	
	cout<<"-1 -1"<<endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
