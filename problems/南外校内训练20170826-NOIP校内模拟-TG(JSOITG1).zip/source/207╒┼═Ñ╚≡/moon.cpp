#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <bitset>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
using namespace std;
int n;
long long mod;
long long pow26[2005];
long long pre[2005];
char s[2005];
int main() {
	freopen("moon.in", "r", stdin);
	freopen("moon.out", "w", stdout);
	int i, j;
	scanf("%s", s + 1);
	for(n = 1; s[n]; n++);
	n--;
	scanf("%lld", &mod);
	if(mod==1) {
		puts("0 0");
		return 0;
	}
	pow26[n] = 1ll;
	for(i = n - 1; i; i--)
		pow26[i] = pow26[i + 1] * 26ll % mod;
	pre[n + 1] = 0ll;
	for(i = n; i; i--)
		pre[i] = (pre[i + 1] + (s[i] - 'A') % mod * pow26[i] % mod) % mod;
	if(pre[1] == 0) {
		puts("0 0");
		return 0;
	}
	for(i = 1; i <= n; i++) {
		for(j = i + 1; j <= n; j++) {
			int cur;
			cur = (pre[1]
				- (s[i] - 'A') % mod * pow26[i] % mod
				- (s[j] - 'A') % mod * pow26[j] % mod
				+ mod * 2) % mod;
			cur = (cur
				+ (s[i] - 'A') % mod * pow26[j] % mod
				+ (s[j] - 'A') % mod * pow26[i] % mod) % mod;
			if(cur == 0) {
				printf("%d %d\n", i, j);
				return 0;
			}
		}
	}
	puts("-1 -1");
	return 0;
}
