#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <bitset>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const int N = 20005;
const string KN[11] ={"", "", "", "killing spree", "dominating", "mega kill", "unstoppable"
, "wicked sick", "monster kill", "godlike", "beyond godlike"};
const string KNS[11] ={"", "", "", "is on a killing spree", "is dominating"
, "has a mega kill", "is unstoppable", "is wicked sick", "has a monster kill", "is godlike"
, "is beyond godlike. someone kill him"};
const string SS[2]={"Sentinel", "Scourge"};
map<string, int> players;
int n, bel[N], lastkt[N], cntk[N], cntdtk[N]; //for players
int js[2], bjs[2]; //for Sentinel/Scourge
char str[20], sa[20], sb[20];
int fb;
string rev[N];
void next_kill(int a) {
	cntk[a]++;if(cntk[a]>10) cntk[a]=10;
}
void next_dtk(int a) {
	cntdtk[a]++;if(cntdtk[a]>3) cntdtk[a]=3;
}
string dtk(int a) {
	if(cntdtk[a]==2) return "Double";
	return "Triple";
}
int main() {
	freopen("five.in", "r", stdin);
	freopen("five.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 0; i < n; i++) {
		scanf("%s", str);
		players[(string)str] = i;
		rev[i] = str;
		scanf("%d", &bel[i]);
	}
	fb = true;
	memset(lastkt, -1, sizeof(lastkt));
	int T;
	scanf("%d", &T);
	while(T--) {
		char tim[20];
		scanf("%s", tim);
		int mmm, sss;
		sscanf(tim, "%02d:%02d", &mmm, &sss);
		int nowt = mmm * 60 + sss;
		int a, b;
		scanf("%s", sa);
		scanf("%s", sb);
		scanf("%s", sb);
		scanf("%s", sb);
		scanf("%s", sb);
		//****//
		a = players[sa];
		if(players.find(sb)!=players.end())
			b = players[sb];
		else {
			printf("%s has been killed by %s.\n", sa, sb);
			continue;
		}
		if(a==b) {
			printf("%s has killed himself.\n", sa);
			continue;
		}
		if(cntk[a]>=3)
			printf("%s has just ended %s\'s %s.\n", sb, sa, KN[cntk[a]].c_str());
		else {
			printf("%s pawned %s\'s head.\n", sb, sa);
			if(fb) {
				printf("%s just drew first blood.\n", sb);
				fb=false;
			}
		}
		cntk[a]=0;
		next_kill(b);
		//****//
		//****//
		if(cntk[b]>=3)
			printf("%s %s!\n", sb, KNS[cntk[b]].c_str());
		//****//
		//****//
		if(nowt-lastkt[b]<=10||lastkt[b]==-1) {
			next_dtk(b);
			if(cntdtk[b]>=2)
				printf("%s just got a %s Kill!\n", sb, dtk(b).c_str());
			lastkt[b]=nowt;
		} else if (nowt-lastkt[b]>10) {cntdtk[b]=0;lastkt[b] = -1;}
		//****//
		//****//
		int ba=bel[a], bb=bel[b];
		js[bb]++;
		bjs[ba]++;
		js[ba]=0;
		bjs[bb]=0;
		if(js[bb]>=5)
			printf("The %s is OWNING!\n", SS[bb].c_str());
		//****//
	}
	return 0;
}
