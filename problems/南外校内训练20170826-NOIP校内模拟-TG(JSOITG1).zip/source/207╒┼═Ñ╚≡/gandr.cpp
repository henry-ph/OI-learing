#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <bitset>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const int N = 50005;
int n, m, r;
pair<int, pair<int, int> > e[N];
bool used[N];
bool cmp(const pair<int, pair<int, int> > &t1, const pair<int, pair<int, int> > &t2) {
	return t1.first > t2.first;
}
int main() {
	freopen("gandr.in", "r", stdin);
	freopen("gandr.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &r);
	for(int i = 0; i < r; i++) {
		int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
		v += n;
		e[i] = make_pair(w, make_pair(u, v));
	}
	sort(e, e + r, cmp);
	int res = (n + m) * 10000;
	for(int i = 0; i < r; i++) {
		int u = e[i].second.first, v = e[i].second.second, w = e[i].first;
		if(used[u] && used[v]) continue;
		used[u] = used[v] = true;
		res -= w;
	}
	printf("%d\n", res);
	return 0;
}
