#include<iostream>
#include<cstdio>
#include<stack>
#include<map>
#include<set>
#include<cstring>
#include<string>
#include<iomanip>
#include<queue>
#include<vector>
#include<fstream>
#include<bitset>
#include<algorithm>
#include<cstdlib>
#include<cmath>
using namespace std;

typedef long long ll;
const int N=20000;
const int M=50000;
#define make_pair mp
#define push_back pb
map<string,int> index;
set<string> set_s;
int n,m;
string name[N+5];
int group[N+5],ls[N+5];
struct node
{
	int t,num;
}ds[N+5];

struct info_group
{
	int num;
}js[2];
int tim(int hhours,int mminutes)
{
	return hhours*60+mminutes;
}

int main()
{
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	cin>>n;
	string str;
	int x;
	for (int i=1;i<=n;i++)
	{
		cin>>str;
		scanf("%d",&x);
		set_s.insert(str);
		group[i]=x;
		ds[i].t=-1;
		name[i]=str;
		index[str]=i;
	}
	cin>>m;
	char ch;
	bool first_blood=false;
	for (int i=1;i<=m;i++)
	{
		//input time
		int x,y;
		while (ch<'0'||ch>'9') {ch=getchar();}
		x=(int(ch)-48)*10;
		ch=getchar();
		x+=(int(ch)-48);
		ch=getchar();ch=getchar();
		y=(int(ch)-48)*10;
		ch=getchar();
		y+=(int(ch)-48);
		int tt=tim(x,y);
		ch=getchar();
		//input names
		ch=getchar();
		string name1="",name2="";
		name1+=ch;
		while (ch!=' ') 
		{
			ch=getchar();
			if (ch!=' ') name1+=ch;
		}
		for (int j=1;j<=13;j++) ch=getchar();
		if (i==m) cin>>name2;
		else {
		ch=getchar();
		name2+=ch;
		while (ch!='\n') {ch=getchar();if (ch!='\n') name2+=ch;}
	}
		//cout<<name1<<endl<<name2<<endl<<tt<<endl;
		
		//if it is not a player
		if (set_s.find(name2)==set_s.end()) 
		{
			cout<<name1<<" has been kill by "<<name2<<'.'<<endl;
			continue;
		}
		//if it is him/herself
		if (name1==name2)
		{
			cout<<name1<<" has killed himself.\n";
			continue;
		}
		int p1=index[name2],p2=index[name1];
		// output 1,(2)
		if (ls[p2]>=3) 
		{
			string strr;
			if (ls[p2]==3) strr="killing spree";
			if (ls[p2]==4) strr="dominating";
			if (ls[p2]==5) strr="mega kill";
			if (ls[p2]==6) strr="unstoppable";
			if (ls[p2]==7) strr="wicked sick";
			if (ls[p2]==8) strr="monster kill";
			if (ls[p2]==9) strr="godlike";
			if (ls[p2]>=10) strr="beyond godlike";
			cout<<name2<<" has just ended "<<name1<<"'s "<<strr<<".\n";
		}
		else 
		{
			cout<<name2<<" pawned "<<name1<<"'s head.\n";
		}
		// output 1,(1)
		if (!first_blood) 
		{
			first_blood=true;
			cout<<name2<<" just drew first blood.\n";
		}
		
		//end p2's ls
		ls[p2]=0;
		
		//output 2
		ls[p1]++;
		if (ls[p1]>=3)
		{
			string strrr;
			if (ls[p1]==3) strrr="is on a killing spree!";
			if (ls[p1]==4) strrr="is dominating!";
			if (ls[p1]==5) strrr="has a mega kill!";
			if (ls[p1]==6) strrr="is unstoppable!";
			if (ls[p1]==7) strrr="is wicked sick!";
			if (ls[p1]==8) strrr="has a monster kill!";
			if (ls[p1]==9) strrr="is godlike!";
			if (ls[p1]>=10) strrr="is beyond godlike. someone kill him!";
			cout<<name2<<' '<<strrr<<'\n';
		}
		//output 3
		
		if (ds[p1].t+10>=tt) ds[p1].num++;
		else ds[p1].num=1;
		ds[p1].t=tt;
		if (ds[p1].num==2) cout<<name2<<" just got a Double Kill!\n";
		if (ds[p1].num>=3) cout<<name2<<" just got a Triple Kill!\n";
		
		//output 4
		js[group[p2]].num=0;
		js[group[p1]].num++;
		int team=group[p1];
		if (js[team].num>=5) 
		{
			if (team==0) printf("The Sentinel is OWNING!\n");
			else printf("The Scourge is OWNING!\n");
		}
		//cout<<i<<endl;
	}
	return 0;
}

