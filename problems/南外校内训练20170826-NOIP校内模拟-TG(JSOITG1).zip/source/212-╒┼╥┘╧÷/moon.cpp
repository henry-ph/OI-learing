#include<iostream>
#include<cstdio>
#include<stack>
#include<map>
#include<set>
#include<cstring>
#include<string>
#include<iomanip>
#include<queue>
#include<vector>
#include<fstream>
#include<bitset>
#include<algorithm>
#include<cstdlib>
#include<cmath>
using namespace std;

typedef long long ll;
#define make_pair mp
#define push_back pb
ll l,m,ans,t;
ll p[3001][30];
string s;

void init()
{
	long long pro=1;
	for (int i=0;i<=10;i++) 
	{
		if (i!=0) {pro*=26;pro%=m;}
		//cout<<pro<<endl;
		for (int j=0;j<=25;j++) 
		{
			p[i][j]=(pro*j)%m;
			//cout<<p[i][j]<<' ';
		}
		//cout<<endl;
	}
}

int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>s;
	cin>>m;
	int l=s.length();
	init();
	ans=0;
	bool flag=false;
	int ansi=-1,ansj=-1;
	for (int i=l-1;i>=0;i--) 
	{
		ans=(ans+p[l-i-1][int(s[i]-65)])%m;
	}
	//cout<<ans<<endl;
	if (ans%m==0) {cout<<0<<' '<<0<<endl;return 0;}
	for (int i=0;i<l-1;i++)
	{
		for (int j=i+1;j<l;j++)
		{
			t=ans-p[l-i-1][int(s[i])-65]-p[l-j-1][int(s[j])-65]+p[l-i-1][int(s[j])-65]+p[l-j-1][int(s[i])-65];
			//cout<<i<<' '<<j<<' '<<t<<endl;
			t%=m;
			if (t%m==0) {flag=true;ansi=i;ansj=j;break;}
		}
		if (flag) break;
	}
	cout<<ansi+1<<' '<<ansj+1<<endl;
	return 0;
}

