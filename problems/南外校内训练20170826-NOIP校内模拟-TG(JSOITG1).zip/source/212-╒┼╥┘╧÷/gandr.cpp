#include<iostream>
#include<cstdio>
#include<stack>
#include<map>
#include<set>
#include<cstring>
#include<string>
#include<iomanip>
#include<queue>
#include<vector>
#include<fstream>
#include<bitset>
#include<algorithm>
#include<cstdlib>
#include<cmath>
using namespace std;

typedef long long ll;
struct edge
{
	int from,to,w;
}e[100001];

#define make_pair mp
#define push_back pb
int m1,n1,r;
int n;
int p[20001];

bool cmp(edge a,edge b) 
{
	return a.w<b.w;
}

int find(int x) 
{
	if (x!=p[x]) p[x]=find(p[x]);
	return p[x];
}

int main()
{
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	cin>>m1>>n1>>r;
	int x,y,d;
	n=m1+n1;
	for (int i=1;i<=r;i++) 
	{
		scanf("%d%d%d",&x,&y,&d);
		y+=m1;
		d=10000-d;
		e[i].from=x;e[i].to=y;e[i].w=d;
	}
	for (int i=0;i<=n;i++) p[i]=i;
	sort(e+1,e+r+1,cmp);
	int sum=n;
	int ans=0;
	for (int i=1;i<=r;i++) 
	{
		if (sum==0) break;
		x=e[i].from;
		y=e[i].to;
		x=find(x);y=find(y);
		if (x!=y) 
		{
			p[x]=y;
			ans+=e[i].w;
			sum--;
		}
	}
	ans+=sum*10000;
	cout<<ans<<endl;
	return 0;
}

