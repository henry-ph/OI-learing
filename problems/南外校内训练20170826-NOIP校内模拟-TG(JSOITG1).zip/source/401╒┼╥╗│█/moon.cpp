#include<stdio.h>
char buf[1000000],*p1,*p2;
inline bool isdigit(const char &ch){
	return ch>=48&&ch<=57;
}
inline char nextchar(){
	return p1==p2&&(p2=buf+fread(p1=buf,1,1000000,stdin),p1==p2)?EOF:*p1++;
}
inline void getint(int &des){
	char ch=des=0;
	while(!isdigit(ch))ch=nextchar();
	while(isdigit(ch))des=des*10+ch-48,ch=nextchar();
}
inline void getstr(int *str){
	char ch=0;
	while(ch<=32)ch=nextchar();
	do(*str++)=ch;while((ch=nextchar())>32);
	*(str++)=0;
}
inline int strlen(const int *str){
	int ret=0;
	while(*(str+(ret++))){
		ret=ret;
	}
	return ret-1;
}
template<typename Tp>
inline void swap(Tp &a,Tp &b){
	Tp tmp;
	tmp=a;
	a=b,b=tmp;
}
template<typename Tp>
inline void reverse(Tp *beg,Tp *end){
	while(beg<end){
		swap(*beg++,*--end);
	}
}
int magic[2010];
int m,n,s;
int mod[26][2010];
int main(){
	int i,j,k;
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	getstr(magic);
	getint(m);
	n=strlen(magic);
	for(i=0;i!=n;++i){
		magic[i]-=65;
	}
	reverse(magic,magic+n);
	for(i=0;i!=26;++i){
		mod[i][0]=i%m;
		for(j=1;j!=n;++j){
			mod[i][j]=(mod[i][j-1]*26)%m;
		}
	}
	for(i=0;i!=n;++i){
		s+=mod[magic[i]][i];
		s%=m;
	}
	if(!s){
		printf("0 0\n");
		return 0;
	}
	for(i=n-1;i>=0;--i){
		for(j=i-1;j>=0;--j){
			if(!(s-mod[magic[i]][i]-mod[magic[j]][j]+mod[magic[i]][j]+mod[magic[j]][i])%m){
				printf("%d %d\n",n-i,n-j);
				return 0;
			}
		}
	}
	printf("-1 -1\n");
}
