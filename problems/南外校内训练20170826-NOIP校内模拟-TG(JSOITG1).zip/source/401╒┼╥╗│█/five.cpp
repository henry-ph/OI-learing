#include<cstdio>
#include<algorithm>
#include<string>
#include<cstring>
#include<vector>
using namespace std;
char buf[1000000],*p1,*p2;
inline bool isdigit(const char &ch){
	return ch>=48&&ch<=57;
}
inline char nextchar(){
	return p1==p2&&(p2=buf+fread(p1=buf,1,1000000,stdin),p1==p2)?EOF:*p1++;
}
inline void getint(int &des){
	char ch=des=0;
	while(!isdigit(ch))ch=nextchar();
	while(isdigit(ch))des=des*10+ch-48,ch=nextchar();
}
inline void getstr(char *str){
	char ch=0;
	while(ch<=32)ch=nextchar();
	do(*str++)=ch;while((ch=nextchar())>32);
	*(str++)=0;
}
char BUF[1000000],*P1=BUF;
const char *P2=BUF+1000000;
inline void addchar(const char &ch){
	if(P1==P2)fwrite(P1=BUF,1,1000000,stdout);
	(*P1++)=ch;
}
void putstr(const char *str){
	while(*str)addchar(*str++);
}
inline void close(){
	fwrite(BUF,1,P1-BUF,stdout);
}
const int mod=(1<<20)-1;
const int INF=0x3fffffff;
bool firstblood=false;
string title[11];
class gp{
	public:
		gp(){
			n=0;
			memset(killcnt,0,sizeof(killcnt));
			for(int i=1;i<=20000;i++){
				lastkill[i]=-INF;
			}
			memset(doublekill,0,sizeof(doublekill));
			groupkill=0;
		}
		int n;
		string name[20010];
		int hsh[20010];
		vector<int>table[1048576];
		int killcnt[20010];
		int lastkill[20010];
		bool doublekill[20010];
		int groupkill;
		inline int haash(const string &s){
			int ret=0;
			for(int i=0;i<s.size();++i){
				ret=(ret<<7)+s[i];
				ret&=mod;
			}
			return ret;
		}
		inline void addplayer(const string &s){
			++n;
			name[n]=s;
			hsh[n]=haash(s);
			table[hsh[n]].push_back(n);
		}
		inline int exist(const string &s){
			int h=haash(s);
			for(int i=0;i<table[h].size();++i){
				if(name[table[h][i]]==s)return table[h][i];
			}
			return 0;
		}
		inline bool check1(const int &killer){
			if(killcnt[killer]<3)return false;
			putstr(name[killer].c_str());
			switch(killcnt[killer]){
				case 3:
					putstr(" is on a killing spree!\n");
					break;
				case 4:
					putstr(" is dominating!\n");
					break;
				case 5:
					putstr(" has a mega kill!\n");
					break;
				case 6:
					putstr(" is unstoppable!\n");
					break;
				case 7:
					putstr(" is wicked sick!\n");
					break;
				case 8:
					putstr(" has a monster kill!\n");
					break;
				case 9:
					putstr(" is godlike!\n");
					break;
				default:
					putstr(" is beyond godlike. someone kill him!\n");
					break;
			}
			return true;
		}
		inline bool check2(const int &killer,const int &t){
			if(t<=lastkill[killer]+10){
				putstr(name[killer].c_str());
				if(doublekill[killer]){
					putstr(" just got a Triple Kill!\n");
				}else{
					putstr(" just got a Double Kill!\n");
					doublekill[killer]=true;
				}
				return true;
			}else{
				doublekill[killer]=false;
				return false;
			}
		}
		inline void addkill(const int &killer,const int &t){
			++killcnt[killer];
			check1(killer);
			check2(killer,t);
			lastkill[killer]=t;
			++groupkill;
		}
		inline void adddeath(const int &sucker){
			killcnt[sucker]=0;
			groupkill=0;
		}
}sc,se;
int n,m;
int main(){
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	title[3]="killing spree";
	title[4]="dominating";
	title[5]="mega kill";
	title[6]="unstoppable";
	title[7]="wicked sick";
	title[8]="monster kill";
	title[9]="godlike";
	title[10]="beyond godlike";
	int i,j,k,a,b,t,p1,p2;
	char str[20];
	string s1,s2;
	getint(n);
	for(i=1;i<=n;++i){
		getstr(str);
		s1=str;
		getint(k);
		if(k){
			sc.addplayer(s1);
		}else{
			se.addplayer(s1);
		}
	}
	getint(m);
	for(i=1;i<=m;i++){
		getint(a);getint(b);
		t=a*60+b;
		getstr(str);
		s1=str;
		getstr(str);
		getstr(str);
		getstr(str);
		getstr(str);
		s2=str;
		if(p1=sc.exist(s1)){
			if(p2=se.exist(s2)){
				if(sc.killcnt[p1]>=3){
					putstr(s2.c_str());
					putstr(" has just ended ");
					putstr(s1.c_str());
					putstr("'s ");
					putstr(title[min(10,sc.killcnt[p1])].c_str());
					putstr(".\n");
				}else{
					putstr(s2.c_str());
					putstr(" pawned ");
					putstr(s1.c_str());
					putstr("'s head.\n");
				}
				if(!firstblood){
					firstblood=true;
					putstr(s2.c_str());
					putstr(" just drew first blood.\n");
				}
				se.addkill(p2,t);
				if(se.groupkill>=5){
					putstr("The Sentinel is OWNING!\n");
				}
				sc.adddeath(p1);
			}else{
				if(s1==s2){
					putstr(s1.c_str());
					putstr(" has killed himself.\n");
				}else{
					putstr(s1.c_str());
					putstr(" has been killed by ");
					putstr(s2.c_str());
					putstr(".\n");
				}
			}
		}else{
			p1=se.exist(s1);
			if(p2=sc.exist(s2)){
				if(se.killcnt[p1]>=3){
					putstr(s2.c_str());
					putstr(" has just ended ");
					putstr(s1.c_str());
					putstr("'s ");
					putstr(title[min(10,se.killcnt[p1])].c_str());
					putstr(".\n");
				}else{
					putstr(s2.c_str());
					putstr(" pawned ");
					putstr(s1.c_str());
					putstr("'s head.\n");
				}
				if(!firstblood){
					firstblood=true;
					putstr(s2.c_str());
					putstr(" just drew first blood.\n");
				}
				sc.addkill(p2,t);
				if(sc.groupkill>=5){
					putstr("The Sentinel is OWNING!\n");
				}
				se.adddeath(p1);
			}else{
				if(s1==s2){
					putstr(s1.c_str());
					putstr(" has killed himself.\n");
				}else{
					putstr(s1.c_str());
					putstr(" has been killed by ");
					putstr(s2.c_str());
					putstr(".\n");
				}
			}
		}
	}
	close();
	return 0;
}
