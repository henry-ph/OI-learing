#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std; 
struct Edge
{
	int u, v, w; 
	inline bool operator <(const Edge &a) const
	{
		return w > a.w; 
	}
} edge[50005]; 
struct DSU
{
	int fa[20005]; 
	DSU()
	{
		for (int i = 0; i < 20005; i++)
			fa[i] = i; 
	}
	int getfa(int u)
	{
		if (u == fa[u])
			return u; 
		return fa[u] = getfa(fa[u]); 
	}
	inline void unite(int u, int v)
	{
		u = getfa(u); 
		v = getfa(v);
		if (u != v)
			fa[u] = v; 
	}
	inline bool same(int u, int v)
	{
		return getfa(u) == getfa(v); 
	}
} dsu; 
int main()
{
	freopen("gandr.in", "r", stdin); 
	freopen("gandr.out", "wt", stdout); 
	int n, m, k, ans = 0; 
	scanf("%d%d%d", &n, &m, &k); 
	for (int i = 0; i < k; i++)
		scanf("%d%d%d", &edge[i].u, &edge[i].v, &edge[i].w); 
	sort(edge, edge + k); 
	for (int i = 0; i < k; i++)
	{
		if (dsu.same(edge[i].u, edge[i].v + n))
			continue; 
		ans += edge[i].w; 
		dsu.unite(edge[i].u, edge[i].v + n); 
	}
	printf("%d\n", 10000 * (n + m) - ans); 
	return 0; 
}

