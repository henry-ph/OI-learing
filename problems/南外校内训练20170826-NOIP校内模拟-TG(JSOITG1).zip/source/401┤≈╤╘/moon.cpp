#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
char str[2005]; 
int p[2005], m; 
inline void del(int &x, char c, int pos)
{
	x = ((x - (c - 'A') * p[pos] % m) % m + m) % m; 
}
inline void add(int &x, char c, int pos)
{
	x = (x + (c - 'A') * p[pos] % m) % m; 
}
int main()
{
	freopen("moon.in", "r", stdin); 
	freopen("moon.out", "wt", stdout); 
	scanf("%s", str); 
	int len = strlen(str); 
	int cur = 0; 
	scanf("%d", &m); 
	if (len <= 500)
	{
		for (int i = 0; i < len; i++)
			cur = (cur * 26 + str[i] - 'A') % m;
		if (!cur)
		{
			printf("0 0\n"); 
			return 0; 
		}
		for (int i = 0; i < len; i++)
		{
			for (int j = i + 1; j < len; j++)
			{
				swap(str[i], str[j]); 
				cur = 0; 
				for (int k = 0; k < len; k++)
					cur = (cur * 26 + str[k] - 'A') % m; 
				if (!cur)
				{
					printf("%d %d\n", i + 1, j + 1); 
					return 0; 
				}
				swap(str[i], str[j]);
			}
		}
		printf("-1 -1\n"); 
		return 0; 
	}
	p[len - 1] = 1; 
	for (int i = len - 2; i >= 0; i--)
		p[i] = p[i + 1] * 26 % m; 
	for (int k = 0; k < len; k++)
		add(cur, str[k], k); 
	if (!cur)
	{
		printf("0 0\n"); 
		return 0; 
	}
	for (int i = 0; i < len; i++)
	{
		for (int j = i + 1; j < len; j++)
		{
			int x = cur; 
			del(x, str[i], i); 
			add(x, str[j], i); 
			del(x, str[j], j); 
			add(x, str[i], j); 
			if (!x)
			{
				printf("%d %d\n", i + 1, j + 1); 
				return 0; 
			}
		}
	}
	printf("-1 -1\n"); 
	return 0; 
}

