#include <iostream>
#include <cstring>
#include <cstdio>
#include <string>
#include <map>
using namespace std; 
map<string, int> app, cnt, lst, mul; 
int tot[2]; 
char name[][105] = 
{
	"",
	"",
	"",
	"killing spree",
	"dominating",
	"mega kill",
	"unstoppable",
	"wicked sick",
	"monster kill",
	"godlike",
	"beyond godlike"
};
char word[][105] = 
{
	"",
	"",
	"",
	"is on a killing spree",
	"is dominating",
	"has a mega kill",
	"is unstoppable",
	"is wicked sick",
	"has a monster kill",
	"is godlike",
	"is beyond godlike. someone kill him"
};
char team[][105] = 
{
	"Sentinel",
	"Scourge"
}; 
char str[105], killer[105]; 
inline string trans(char *x)
{
	int len = strlen(x); 
	string res(strlen(x), 0); 
	for (int i = 0; i < len; i++)
		res[i] = x[i]; 
	return res; 
}
int main()
{
	freopen("five.in", "r", stdin); 
	freopen("five.out", "wt", stdout); 
	int n; 
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		int x; 
		scanf("%s%d", str, &x); 
		app[trans(str)] = x; 
	}
	int q; 
	scanf("%d", &q); 
	bool fst = true; 
	while (q--)
	{
		int m, s; 
		scanf("%d:%d %s is killed by %s", &m, &s, str, killer); 
		string a = trans(str), b = trans(killer);
		if (a == b)
		{
			printf("%s has killed himself.\n", str); 
			continue; 
		}
		if (!app.count(b))
		{
			printf("%s has been killed by %s.\n", str, killer); 
			continue; 
		}
		if (cnt[a] >= 3)
			printf("%s has just ended %s's %s.\n", killer, str, name[cnt[a]]); 
		else
			printf("%s pawned %s's head.\n", killer, str);
		cnt[a] = 0; 
		if (fst)
		{
			fst = false; 
			printf("%s just drew first blood.\n");
		}
		if (++cnt[b] >= 3)
			printf("%s %s!\n", killer, word[cnt[b] >= 10 ? 10 : cnt[b]]); 
		if (lst[b] >= m * 60 + s - 10)
		{
			mul[b]++; 
			printf("%s just got a %s Kill!\n", killer
			, mul[b] >= 3 ? "Triple" : "Double"); 
		}
		else
			mul[b] = 1; 
		lst[b] = m * 60 + s; 
		if (++tot[app[b]] >= 5)
			printf("The %s is OWNING!\n", team[app[b]]); 
		tot[app[a]] = 0; 
	}
	return 0; 
}

