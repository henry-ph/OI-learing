#include <cstdio>
#include <cstring>
#include <string>
#include <map>
using namespace std;
int n,m;
map<string,bool> team;
map<string,int> cons;
map<string,int> last;
map<string,int> mulc;
string ckh[]={"","","","killing spree","dominating","mega kill","unstoppable","wicked sick","monster kill","godlike","beyond godlike"};
inline string conv(char s[]){
	string res;
	for(int i=0;i<strlen(s);i++){
		res+=s[i];
	}
	return res;
}
int main(){
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		char ch[20];
		int t;
		scanf("%s%d",ch,&t);
		team[conv(ch)]=t;
	}
	scanf("%d",&m);
	bool fb=false;
	int tcnt[2]={0,0};
	while(m--){
		int mm,ss,t;
		char ca[20],cb[20];
		scanf("%d:%d %s is killed by %s",&mm,&ss,ca,cb);
		string a=conv(ca),b=conv(cb);
		t=mm*60+ss;
		//type 1
		if(a==b)printf("%s has killed himself.\n",ca);
		else if(!team.count(b))printf("%s has been killed by %s.\n",ca,cb);
		else{
			if(cons[a]>=3){
				if(cons[a]>10)printf("%s has just ended %s's beyond godlike.\n",cb,ca);
				else printf("%s has just ended %s's %s.\n",cb,ca,ckh[cons[a]].c_str());
			}
			else printf("%s pawned %s's head.\n",cb,ca);
			cons[a]=0;
			cons[b]++;
			tcnt[team[b]]++;
			tcnt[team[b]^1]=0;
			if(!fb){
				fb=true;
				printf("%s just drew first blood.\n",cb);
			}
			//type 2
			if(cons[b]==3)printf("%s is on a killing spree!\n",cb);
			else if(cons[b]==4)printf("%s is dominating!\n",cb);
			else if(cons[b]==5)printf("%s has a mega kill!\n",cb);
			else if(cons[b]==6)printf("%s is unstoppable!\n",cb);
			else if(cons[b]==7)printf("%s is wicked sick!\n",cb);
			else if(cons[b]==8)printf("%s has a monster kill!\n",cb);
			else if(cons[b]==9)printf("%s is godlike!\n",cb);
			else if(cons[b]>=10)printf("%s is beyond godlike. someone kill him!\n",cb);
			//type 3
			if(t-last[b]<=10){
				mulc[b]++;
				if(mulc[b]==2)printf("%s just got a Double Kill!\n",cb);
				else printf("%s just got a Triple Kill!\n",cb);
			}
			else mulc[b]=1;
			last[b]=t;
			//type 4
			if(tcnt[team[b]]>=5){
				if(team[b])printf("The Scourge is OWNING!\n");
				else printf("The Sentinel is OWNING!\n");
			}
		}
	}
	return 0;
}
