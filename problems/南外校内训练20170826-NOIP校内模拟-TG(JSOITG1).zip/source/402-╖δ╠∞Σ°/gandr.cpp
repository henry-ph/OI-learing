#include <cstdio>
#include <utility>
#include <algorithm>
#define C first
#define U second.first
#define V second.second
using namespace std;
int n,m,r,ans,par[20005];
pair<int,pair<int,int> > ed[50005];
inline int fnd(int x){
	if(par[x]==x)return x;
	return par[x]=fnd(par[x]);
}
int main(){
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	scanf("%d%d%d",&n,&m,&r);
	for(int i=0;i<n+m;i++){
		par[i]=i;
	}
	for(int i=0;i<r;i++){
		scanf("%d%d%d",&ed[i].U,&ed[i].V,&ed[i].C);
	}
	sort(ed,ed+r);
	for(int i=r-1;i>=0;i--){
		if(fnd(ed[i].U)!=fnd(n+ed[i].V)){
			ans+=ed[i].C;
			par[fnd(ed[i].U)]=fnd(n+ed[i].V);
		}
	}
	printf("%d\n",(n+m)*10000-ans);
	return 0;
}
