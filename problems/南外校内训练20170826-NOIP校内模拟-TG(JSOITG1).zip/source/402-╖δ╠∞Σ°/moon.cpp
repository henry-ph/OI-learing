#include <cstdio>
#include <cstring>
using namespace std;
char s[2005];
int n,m,pw[2005];
int main(){
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	scanf("%s%d",&s,&m);
	n=strlen(s);
	pw[0]=1;
	for(int i=1;i<n;i++){
		pw[i]=pw[i-1]*26%m;
	}
	int md=0;
	for(int i=0;i<n;i++){
		md=(md+(s[i]-'A')*pw[n-1-i]%m)%m;
	}
	if(!md){
		puts("0 0");
		return 0;
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			int nmd=md;
			nmd=(nmd-(s[i]-'A')*pw[n-1-i]%m+m)%m;
			nmd=(nmd-(s[j]-'A')*pw[n-1-j]%m+m)%m;
			nmd=(nmd+(s[j]-'A')*pw[n-1-i]%m)%m;
			nmd=(nmd+(s[i]-'A')*pw[n-1-j]%m)%m;
			if(!nmd){
				printf("%d %d\n",i+1,j+1);
				return 0;
			}
		}
	}
	puts("-1 -1");
	return 0;
}
