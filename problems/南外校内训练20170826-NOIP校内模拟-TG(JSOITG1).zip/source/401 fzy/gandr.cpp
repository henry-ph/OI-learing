#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <queue>
using namespace std;
int n,m,k;
long long ans;
int fa[200005];
struct Edge{
    long long w;
	int u,v;
}edge[200005];
bool cmp(const Edge &x,const Edge &y){
	return x.w<y.w;
}
int getfather(int x){
	if (fa[x]==x){
		return x;
	}
	else{
		return fa[x]=getfather(fa[x]);
	}
}
void Union(int x,int y){
	int fx=getfather(x);
	int fy=getfather(y);
	if (fx==fy){
		return;
	}
	else{
		fa[fx]=fy;
	}
}
void pre(){
	for (int i=0;i<n+m;i++){
		fa[i]=i;
	}
}
bool same(int x,int y){
	if (getfather(x)==getfather(y)){
		return true;
	}
	else{
		return false;
	}
}
void solve(){
	for (int e=1;e<=k;e++){
		int u=edge[e].u;
		int v=edge[e].v;
		long long w=edge[e].w;
		if (same(u,v)){
			continue;
		}
		Union(u,v);
		ans+=w;
	}
}
int main(){
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	//pre();
	for (int e=1;e<=k;e++){
		scanf("%d%d%lld",&edge[e].u,&edge[e].v,&edge[e].w);
		edge[e].v+=n;
		edge[e].w=10000ll-edge[e].w;
		//Union(edge[e].u,edge[e].v);
	}
	sort(edge+1,edge+k+1,cmp);
	pre();
	solve();
	int cnt=0;
	for (int i=0;i<n+m;i++){
		if (fa[i]==i){
			cnt++;
		}
	}
	ans+=(long long)cnt*10000ll;
	printf("%lld",ans);
	return 0;
}
