#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <queue>
using namespace std;
string s;
int len;
long long K;

void solve1(){
	long long Pow[15];
	Pow[0]=1;
	for (int i=1;i<=10;i++){
		Pow[i]=Pow[i-1]*26;
	}
	long long num=0;
	for (int k=len-1;k>=0;k--){
		num+=Pow[len-k-1]*(long long)(s[k]-'A');
	}
	if (num%K==0){
		cout<<"0 0";
		return;
	}
	for (int i=0;i<len;i++){
		for (int j=i+1;j<len;j++){
			swap(s[i],s[j]);
			long long num=0;
			for (int k=len-1;k>=0;k--){
				num+=Pow[len-k-1]*(long long)(s[k]-'A');
			}
			if (num%K==0){
				cout<<i+1<<" "<<j+1;
				return;
			}
			swap(s[i],s[j]);
		}
	}
	cout<<"-1 -1";
	return;
}
void solve2(){
	int num=0;
	for (int i=0;i<len;i++){
		num+=(s[i]-'A');
	}
	if (num%K==0){
		cout<<"0 0";
	}
	else{
		cout<<"-1 -1";
	}
	return;
}
void solve3(){
	if (s[len-1]=='A'){
		cout<<"0 0";
		return;
	}
	bool flag=false;
	int plA=-1;
	for (int i=0;i<len;i++){
		if (s[i]=='A'){
			flag=true;
			plA=i;
			break;
		}
	}
	if (!flag){
		cout<<"-1 -1";
	}
	else{
		cout<<plA+1<<" "<<len;
	}
	return;
}
int main(){
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>s;
	len=s.size();
	cin>>K;
	if (len<=10){
		solve1();
	}
	else if (K==5 || K==25){
		solve2();
	}
	else if (K==26){
		solve3();
	}
	else{
		cout<<"-1 -1";
	}
	return 0;
}
