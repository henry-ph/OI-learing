#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <set>
#include <vector>
#include <queue>
#include <map>
using namespace std;
int n,m;
struct Node{
	string name;
	int id;
	int side;
	int cnt2;
	int cnt3;
	int lstmin;
	int lstsec;
}p[20005];
map<string,int> mp;
int cnt0,cnt1;
bool check(int x,int y){
	return x!=y;
}
bool first=false;
string getName(int id){
	if (p[id].cnt2==3){
		return "killing spree";
	}
	else if (p[id].cnt2==4){
		return "dominating";
	}
	else if (p[id].cnt2==5){
		return "mega kill";
	}
	else if (p[id].cnt2==6){
		return "unstoppable";
	}
	else if (p[id].cnt2==7){
		return "wicked sick";
	}
	else if (p[id].cnt2==8){
		return "monster kill";
	}
	else if (p[id].cnt2==9){
		return "godlike";
	}
	else{
		return "beyond godlike";
	}
}
int getTime(int killer,int min,int sec){
	return 60*(min-p[killer].lstmin)+(sec-p[killer].lstsec);
}
void solve1(int min,int sec,int killed,int killer){
	p[killer].cnt2++;
	if (getTime(killer,min,sec)<=10){
		p[killer].cnt3++;
	}
	else{
		p[killer].cnt3=0;
	}
	p[killer].lstsec=sec;
	p[killer].lstmin=min;
	for (int i=1;i<=n;i++){
		if (i==p[killer].id){
			continue;
		}
		p[i].cnt2=0;
	}
	
	if (check(killed,killer)){
		if (p[killer].side==-1){
			cout<<p[killed].name<<" has been killed by "<<p[killer].name<<"."<<endl;
			if (p[killer].side==0){
				cnt0++;
				cnt1=0;
			}
			else{
				cnt1++;
				cnt0=0;
			}
			return;
		}
		if (p[killed].cnt2>=3){
			cout<<p[killer].name<<" has just ended "<<p[killed].name<<"'s "<<getName(p[killed].id)<<"."<<endl;
			//cout<<p[killer].name<<" pawned "<<p[killed].name<<"' head."<<endl;
			if (p[killer].side==0){
				cnt0++;
				cnt1=0;
			}
			else{
				cnt1++;
				cnt0=0;
			}
		}
		cout<<p[killer].name<<" pawned "<<p[killed].name<<" head."<<endl;
		if (!first){
			//cout<<p[killer].name<<" pawned "<<p[killed].name<<"' head."<<endl;
			cout<<p[killer].name<<" just drew first blood."<<endl;
			first=true;
		}
	}
	else{
		cout<<p[killer].name<<" has killed himself."<<endl;
	}
}
void Get(int id){
	if (p[id].cnt2==3){
		cout<<" is on a killing spree!";
	}
	else if (p[id].cnt2==4){
		cout<<" is dominating!";
	}
	else if(p[id].cnt2==5){
		cout<<" has a mega kill!";
	}
	else if (p[id].cnt2==6){
		cout<<" is unstoppable!";
	}
	else if (p[id].cnt2==7){
		cout<<" is wicked sick!";
	}
	else if (p[id].cnt2==8){
		cout<<" has a monster kill!";
	}
	else if (p[id].cnt2==9){
		cout<<" is godlike!";
	}
	else{
		cout<<" is beyond godlike. someone kill him!";
	}
}
void solve2(int min,int sec,int killed,int killer){
	//cout<<p[killer].cnt2<<endl;
	if (p[killer].cnt2>=3){
		cout<<p[killer].name;
		Get(p[killer].id);
		cout<<endl;
	}
}
void solve3(int min,int sec,int killed,int killer){
	if (p[killer].cnt3==1){
		cout<<p[killer].name<<" just got a Double Kill!"<<endl;
	}
	else if (p[killer].cnt3>=2){
		cout<<p[killer].name<<" just got a Triple Kill!"<<endl;
	}
}
void solve4(int min,int sec,int killed,int killer){
	if (cnt0>=5){
		cout<<"The Scourge is OWNING!"<<endl;

	}
	else if (cnt1>=5){
		cout<<"The Sentinel is OWNING!"<<endl;
	}
}
int main(){
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
	    cin>>p[i].name>>p[i].side;
	    p[i].id=i;
	    mp[p[i].name]=i;
	}
	cin>>m;
	while (m--){
		string killed,killer;
		string Min,Sec;
		int min,sec;
		string S;
		cin>>S;
		//cout<<S<<endl;
		Min=S.substr(0,2);
		Sec=S.substr(3,2);
		//cout<<Min<<" "<<Sec<<endl;
		min=(Min[0]-'0')*10+(Min[1]-'0');
		sec=(Sec[0]-'0')*10+(Sec[1]-'0');
		cin>>killed;
		cin>>S;
		cin>>S;
		cin>>S;
		cin>>killer;
		if (mp.find(killer)==mp.end()){
			n++;
			p[n].name=killer;
			p[n].id=n;
			p[n].side=-1;
			mp[killer]=n;
		}
		//cout<<min<<" "<<sec<<" "<<mp[killed]<<" "<<mp[killer]<<endl;
		solve1(min,sec,mp[killed],mp[killer]);
		solve2(min,sec,mp[killed],mp[killer]);
		solve3(min,sec,mp[killed],mp[killer]);
		solve4(min,sec,mp[killed],mp[killer]);
	}
	return 0;
}
