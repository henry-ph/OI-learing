#include <iostream>
#include <cstdio>
using namespace std;
#define MAXL 1024
char str[ MAXL ];
int fir[ MAXL ], rest[ MAXL ];
int L, MOD;
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
    scanf("%s", str);
    scanf("%d", &MOD);
    L = 0;
    for (int i = 0; str[i]; i++)
        fir[++L] = str[i] - 'A';
    long long tp, sum = 0;
    rest[L] = 1, sum = fir[L];
    for (int i = L - 1; i >= 1; i--)
    {
        rest[i] = (rest[i + 1] * 26) % MOD;
        sum += rest[i] * fir[i];
    }
    if (sum % MOD == 0) printf("0 0\n");
    else
    {
        int x, y, ans_x, ans_y;
        bool flag = false;
        for (x = 1; x < L && !flag; x++)
            for (y = x + 1; y <= L && !flag; y++)
            {
                tp = sum - rest[x] * fir[x] - rest[y] * fir[y];
                tp += rest[x] * fir[y] + rest[y] * fir[x];
                if (tp % MOD == 0)
                {
                    ans_x = x, ans_y = y;
                    flag = true;
                }
            }
        if (!flag) ans_x = ans_y = -1;
        printf("%d %d\n", ans_x, ans_y);
    }
    return 0;
}
