#include <bits/stdc++.h>
#include <ext/pb_ds/priority_queue.hpp>
#include <ext/pb_ds/hash_policy.hpp>
using namespace std;

const int N = 22222;
const int M = 55555;
#define REP(i, l, r) for (int i = l; i <= r; i++)
struct E{int u, v, c;}edge[M << 1];
int m, n, r, fa[M << 1];

inline void setIO(){
	freopen("gandr.in", "r", stdin);
	freopen("gandr.out", "w", stdout);
}
inline int read(){
	int x = 0, f = 1; char ch = getchar();
	while (!isdigit(ch)) {if (ch == '-') f = -1; ch = getchar();}
	while (isdigit(ch)) {x = x * 10 + ch - '0'; ch = getchar(); }
	return x * f;
}
inline bool cmp(E e1, E e2){ return e1.c > e2.c; }
inline int find(int k){ return fa[k] = fa[k] == k ? k : find(fa[k]); }
int main(){
	setIO();
	
	m = read(); n = read(); r = read();
	REP(i, 1, r) 
		edge[i].u = read() + 1, edge[i].v = read() + 1 + m, edge[i].c = read();
	REP(i, r + 1, r + n + m)
		edge[i].u = i, edge[i].v = n + m + 1, edge[i].c = 0;

	sort(edge + 1, edge + r + n + m, cmp);
	REP(i, 1, n + m + 1) fa[i] = i;
	
	int ans = 0, cnt = 0;
	REP(i, 1, r + n + m){
		if (find(edge[i].u) == find(edge[i].v)) continue;
		cnt++;
		fa[find(edge[i].u)] = find(edge[i].v);
		ans += edge[i].c;
		if (cnt == n + m) break;
	}
	printf("%d\n", (n + m) * 10000 - ans);
	return 0;
}
