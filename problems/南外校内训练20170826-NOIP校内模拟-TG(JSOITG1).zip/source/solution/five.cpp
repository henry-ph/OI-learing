#include <bits/stdc++.h>
using namespace std;

#define rep(i, l, r) for (int i = (l); i <= (r); i++)
#define per(i, r, l) for (int i = (r); i >= (l); i--)
#define MS(_) memset(_, 0, sizeof(_))
#define PB push_back
#define MP make_pair
typedef long long ll;
typedef pair<int, int> PII;
inline void setIO(){
	freopen("five.in", "r", stdin);
	freopen("five.out", "w", stdout);
}

const char consistant_kill[11][50] = {"", "", "",
	"%s is on a killing spree!\n",
	"%s is dominating!\n",
	"%s has a mega kill!\n",
	"%s is unstoppable!\n",
	"%s is wicked sick!\n",
	"%s has a monster kill!\n",
	"%s is godlike!\n",
	"%s is beyond godlike. someone kill him!\n"
};
const char glory[11][20] = {"", "", "",
    "killing spree",
    "dominating",
    "mega kill",
    "unstoppable",
    "wicked sick",
    "monster kill",
    "godlike",
    "beyond godlike"
};
const char plenty_kill[4][30] = {"", "",
    "%s just got a Double Kill!\n",
    "%s just got a Triple Kill!\n"
};
const char team_winning[2][30] = {
    "The Sentinel is OWNING!\n",
    "The Scourge is OWNING!\n"
};

const int INF = 0x7fffffff;
const int LEN = 20;
const int N = 20000 + 100;
int n, m;
map<string, int> num;
int team[N], last_kill_time[N], plenty_kill_cnt[N], team_cnt[N];
pair<bool, int> is_consistant_killing[N];

int main(){
	setIO();

	scanf("%d", &n);
	rep(i, 1, n){ char _name[LEN]; int _team;
		scanf("%s %d", _name, &_team);
		num[string(_name)] = i;	team[i] = _team; 
	}
	
	scanf("%d", &m);
	
	bool first_blood = false;
	rep(i, 1, n) is_consistant_killing[i] = MP(false, 0);
	rep(i, 1, n) last_kill_time[i] = -INF;
	rep(i, 1, n) plenty_kill_cnt[i] = 0;
	team_cnt[0] = 0; team_cnt[1] = 0;
	
	rep(i, 1, m){ int hour, minute; char killer[LEN], bekiller[LEN];
	    scanf("%d:%d %s is killed by %s", &hour, &minute, bekiller, killer);
        int p1 = num[string(killer)], p2 = num[string(bekiller)], killer_team = team[p1];
        int time = hour * 60 + minute;
        if (p1 == p2){ printf("%s has killed himself.\n", killer); } //kill onself
        else if (p1 == 0){ printf("%s has been killed by %s.\n", bekiller, killer); } //killed by Roshan
        else{//player kills player
            
            //basic 
            if (!first_blood){            
                printf("%s pawned %s's head.\n", killer, bekiller);
                printf("%s just drew first blood.\n", killer);
                first_blood = true;    
            }else{             
                if (is_consistant_killing[p2].first){
                    printf("%s has just ended %s's %s.\n", killer, bekiller, 
                        glory[is_consistant_killing[p2].second > 10 ? 10 : is_consistant_killing[p2].second]);
                }else printf("%s pawned %s's head.\n", killer, bekiller);                
                is_consistant_killing[p2].first = false;
                is_consistant_killing[p2].second = 0;
            }
            
            //consistant_killing
            is_consistant_killing[p1].second++;
            if (is_consistant_killing[p1].second >= 3){
                is_consistant_killing[p1].first = true;
                if (is_consistant_killing[p1].second < 10) 
                    printf(consistant_kill[ is_consistant_killing[p1].second ], killer);
                else
                    printf(consistant_kill[10], killer);
            }
            
            //plenty_kill
            if (time - last_kill_time[p1] <= 10){
                plenty_kill_cnt[p1]++;
                if (plenty_kill_cnt[p1] == 2) printf(plenty_kill[2], killer);
                if (plenty_kill_cnt[p1] >= 3) printf(plenty_kill[3], killer);
                
            }else plenty_kill_cnt[p1] = 1;
            last_kill_time[p1] = time;
            
            //team_winning
            team_cnt[killer_team ^ 1] = 0;
            team_cnt[killer_team]++;
            if (team_cnt[killer_team] >= 5) printf(team_winning[killer_team]);
        }
	}

	return 0;
}
