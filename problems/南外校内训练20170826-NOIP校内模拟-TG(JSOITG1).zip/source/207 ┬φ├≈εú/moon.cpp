#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

string m;
int n;

int main()
{
	freopen("r","moon.in",stdin);
	freopen("w","moon.out",stdout);
	cin>>m >>n;
	cout<<"-1 -1";
}
