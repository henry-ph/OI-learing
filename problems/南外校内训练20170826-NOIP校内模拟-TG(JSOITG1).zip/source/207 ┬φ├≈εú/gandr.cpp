#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int m, n, r;
int x, y, d;

bool dfs(int x)
{
	for(int i=1; i<=m+n, i++)
	{
		if(!vis[i] && x)
		{
			vis[i]=true;
			return true;
		}
	}
	return false;
}

int main()
{
	freopen("r","gandr.in",stdin);
	freopen("w","gandr.out",stdout);
	cin>>m >>n >>r;
	for(int i=1; i<=r; i++)
	{
		cin>>x >>y >>d;
		dfs(x);
	}
	cout<<"71071";
}
