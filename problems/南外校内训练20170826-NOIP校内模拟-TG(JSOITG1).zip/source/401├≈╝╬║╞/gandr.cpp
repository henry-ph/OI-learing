#include<bits/stdc++.h>
#define MP make_pair
#define FI first
#define SE second
using namespace std;
typedef long long LL;
typedef pair<int,int> PII;
int m,n,r,x,y,d,ans,p1,p2;
int p[20008],rnk[20008];
priority_queue<pair<int,PII> > q;
int find(int x){return x==p[x]?x:p[x]=find(p[x]);}
void unionn(int x,int y)
{
	if(rnk[x]<rnk[y])	p[x]=y;
	else{
		p[y]=x;
		if(rnk[x]==rnk[y])	rnk[x]++;
	}
}
int main()
{
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	cin>>m>>n>>r;
	for(int i=0;i<m+n;i++)	p[i]=i;
	ans=(m+n)*10000;
	for(int i=1;i<=r;i++){
		cin>>x>>y>>d;
		q.push(MP(d,MP(x,y+m)));
	}
	while(!q.empty()){
		pair<int,PII> now=q.top();q.pop();
		p1=find(now.SE.FI);
		p2=find(now.SE.SE);
		if(p1==p2)	continue;
		unionn(p1,p2);
		ans-=now.FI;
	}
	cout<<ans;
	return 0;
}
