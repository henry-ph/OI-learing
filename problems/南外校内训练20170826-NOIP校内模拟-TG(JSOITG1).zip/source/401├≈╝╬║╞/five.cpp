#include<bits/stdc++.h>
#define MP make_pair
#define FI first
#define SE second
using namespace std;
typedef long long LL;
typedef pair<int,int> PII;
int n,m;
string t,tmp,a,b;
bool ppp,first_blood;
map<string,int> player;
struct node{
	bool zy;
	int tim,knum,dk;
}p[20008];
int tt,mjh[2];
string ch[18],ch2[18];
int main()
{
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	ch[3]="killing spree";
	ch[4]="dominating";
	ch[5]="mega kill";
	ch[6]="unstoppable";
	ch[7]="wicked sick";
	ch[8]="monster kill";
	ch[9]="godlike";
	ch[10]="beyond godlike";
	ch2[3]=" is on a killing spree!";
	ch2[4]=" is dominating!";
	ch2[5]=" has a mega kill!";
	ch2[6]=" is unstoppable!";
	ch2[7]=" is wicked sick!";
	ch2[8]=" has a monster kill!";
	ch2[9]=" is godlike!";
	ch2[10]=" is beyond godlike. someone kill him!";
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>t>>ppp;
		player[t]=i;
		p[i].zy=ppp;
	}
	cin>>m;
	while(m--){
		cin>>t>>a>>tmp>>tmp>>tmp>>b;
		if(player[b]){//������ս� 
			if(b==a){//��ɱ 
				cout<<b<<" has killed himself.\n";
			}
			else{//��Ч��ɱ 
				if(!first_blood){
					cout<<b<<" pawned "<<a<<"'s head.\n";
					cout<<b<<" just drew first blood.\n";
					first_blood=1;
					p[player[b]].tim=t[0]*600+t[1]*60+t[3]*10+t[4];
					mjh[p[player[b]].zy]++;
					p[player[b]].dk=1;
					p[player[b]].knum=1;
				}
				else{
					if(p[player[a]].knum>=3){
						cout<<b<<" has just ended "<<a<<"'s "<<ch[p[player[a]].knum]<<".\n";
					}
					else{
						cout<<b<<" pawned "<<a<<"'s head.\n";
					}
					
					p[player[a]].knum=0;
					mjh[p[player[a]].zy]=0;
					
					p[player[b]].knum++;
					if(p[player[b]].knum>=3){
						cout<<b<<ch2[p[player[b]].knum]<<'\n';
					}
					tt=t[0]*600+t[1]*60+t[3]*10+t[4];
					if(tt-p[player[b]].tim<=10){//��ɱ 
						p[player[b]].dk++;
						if(p[player[b]].dk==2){
							cout<<b<<" just got a Double Kill!\n";
						}
						if(p[player[b]].dk>=3){
							cout<<b<<" just got a Triple Kill!\n";
						}
					}
					else{
						p[player[b]].dk=1;
					}
					p[player[b]].tim=tt;
					mjh[p[player[b]].zy]++;
					if(mjh[p[player[b]].zy]>=5){//���� 
						if(p[player[b]].zy){
							cout<<"The Scourge is OWNING!\n";
						}
						else{
							cout<<"The Sentinel is OWNING!\n";
						}
					}
				}	
			}
		}
		else{//��Ұ���ս� 
			cout<<a<<" has been killed by "<<b<<".\n";
		}
	}
	return 0;
}
