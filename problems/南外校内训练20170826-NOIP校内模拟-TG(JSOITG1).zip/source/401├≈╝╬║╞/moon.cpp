#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
string s;
int m,tmp;
int a[2008],l;
bool vis[28][28];
inline bool ok()
{
	tmp=0;
	for(int i=1;i<=l;i++){
		tmp=tmp*26+a[i];
		tmp%=m;
	}
	if(tmp==0)	return 1;
	return 0;
}
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>s>>m;
	l=s.size();
	for(int i=1;i<=l;i++){
		a[i]=s[i-1]-'A';
	}
	if(m==26){
		if(a[l]==0){
			cout<<"0 0";
			return 0;
		}
		for(int i=1;i<=l;i++){
			if(a[i]==0){
				cout<<i<<' '<<l;
				return 0;
			}
		}
		cout<<"-1 -1";
		return 0;
	}
	if(m==5){
		for(int i=1;i<=l;i++){
			tmp+=a[i];
		}
		if(tmp%5==0){
			cout<<"0 0";
			return 0;
		}
		cout<<"-1 -1";
		return 0;
	}
	if(m==25){
		for(int i=1;i<=l;i++){
			tmp+=a[i];
		}
		if(tmp%25==0){
			cout<<"0 0";
			return 0;
		}
		cout<<"-1 -1";
		return 0;
	}
	if(ok()){
		cout<<"0 0";
		return 0;
	}
	if(l<=400){
		for(int i=1;i<=l;i++){
			for(int j=i+1;j<=l;j++){
				swap(a[i],a[j]);
				if(ok()){
					cout<<i<<' '<<j;
					return 0;
				}
				swap(a[i],a[j]);
			}
		}
		cout<<"-1 -1";
		return 0;
	}
	for(int i=1;i<=l;i++){
		for(int j=i+1;j<=l;j++){
			if(vis[a[i]][a[j]])	continue;
			swap(a[i],a[j]);
			if(ok()){
				cout<<i<<' '<<j;
				return 0;
			}
			swap(a[i],a[j]);
			vis[a[i]][a[j]]=1;
		}
	}
	cout<<"-1 -1";
	return 0;
}
