#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int mg[10005][10005];
vector<int> u[10005];
vector<int> v[10005];
int cnt;
int main()
{
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	int m,n,r;
	cin>>m>>n>>r;
	for (int i=1;i<=r;i++){
		int a,b,c;
		cin>>a>>b>>c;
		u[a].push_back(b);
		v[b].push_back(a);
		cin>>mg[a][b];
		mg[b][a]=mg[a][b];
		cnt+=mg[b][a];
	}
	cout<<10000*(m+n)-cnt<<endl;
}
