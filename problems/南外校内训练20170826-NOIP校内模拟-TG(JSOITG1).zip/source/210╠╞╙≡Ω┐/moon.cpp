#include<iostream>
#include<algorithm>
#include<string>
#include<cstdio>
#include<cstdlib>
using namespace std;
int n;
int maxn=1
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	string s;
	cin>>s;
	int m;
	cin>>m;
	
	for (int i=0;i<s.size();i++){
		n*=m;
		n+=(s[i]-'A'+1);
	}
	if (n%m==0){
		cout<<"0 0"<<endl;
		return 0;
	}
	
}
