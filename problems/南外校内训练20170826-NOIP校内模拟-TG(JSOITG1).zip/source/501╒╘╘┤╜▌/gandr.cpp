#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;
struct node {
	int x,y,z;
}a[10005];
bool b[10005],c[10005];
bool comp (node x,node y) {
	if (x.z>y.z) return true; else return false;
}
int main ( ) {
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	int n,m,r,i,ans=0;
	scanf("%d%d%d",&n,&m,&r);
	for (i=1;i<=r;i++) {
		scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].z);
	}
	sort(a+1,a+r+1,comp);
	for (i=1;i<=r;i++) {
		if (b[a[i].x] && c[a[i].y]) continue;
		if (b[a[i].x]) ans+=10000-a[i].z,c[a[i].y]=true;
		else if (c[a[i].y]) ans+=10000-a[i].z,b[a[i].x]=true;
		else ans+=20000-a[i].z,b[a[i].x]=c[a[i].y]=true;
	}
	for (i=0;i<n;i++) {
		if (!b[i]) ans+=10000;
	}
	for (i=0;i<m;i++) {
		if (!c[i]) ans+=10000;
	}
	printf("%d\n",ans);
	return 0;
}
/*
5 5 8
4 3 6831
1 3 4583
0 0 6592
0 1 3063
3 3 4975
1 3 2049
4 2 2104
2 2 781

71071
*/
