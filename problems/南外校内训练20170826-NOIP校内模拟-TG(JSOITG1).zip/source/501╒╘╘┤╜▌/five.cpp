#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;
map<string,int> name;
int team[20005];
int kil[20005];
string nname[20005];
int lasttime_[20005];
int kil_[20005];
int main ( ) {
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	int n,i;
	scanf("%d",&n);
	for (i=1;i<=n;i++) {
		string name_;
		cin>>name_;
		name[name_]=i;
		scanf("%d",&team[i]);
		team[i]++;
	}
	int m,s[3]={0},minute_,second_;
	bool ff=false;
	string bekilled,kill,useless;
	scanf("%d",&m);
	memset(lasttime_,-1,sizeof(lasttime_));
	for (i=1;i<=m;i++) {
		bool fffff=false;
		scanf("%d:%d",&minute_,&second_);
		int ttime_=minute_*60+second_;
		cin>>bekilled;
		cin>>useless;cin>>useless;cin>>useless;
		cin>>kill;
		if (name[kill]==0) {
			cout<<bekilled<<" has been killed by "<<kill<<"."<<endl;
		}
		else if (kill!=bekilled) {
			int t1=team[name[kill]],t2=team[name[bekilled]];
			if (kil[name[bekilled]]!=0) {
				int ttt_=name[bekilled];
				if (nname[ttt_]!="") {
					cout<<kill<<" has just ended "<<bekilled<<"'s "<<nname[ttt_]<<"."<<endl;
					nname[ttt_]="";
					fffff=true;
				}
			}
			if (!fffff) {
				if (t1==t2 && t1!=0) {
					cout<<bekilled<<" has been killed by "<<kill<<endl;
				}
				else if (t1+t2==3) {
					cout<<kill<<" pawned "<<bekilled<<"'s head."<<endl;
				}
				if (!ff) cout<<kill<<" just drew first blood."<<endl,ff=true;
			}
			int tt_=name[kill];
			kil[tt_]++;kil[name[bekilled]]=0;
			if (kil[tt_]==3) cout<<kill<<" is on a killing spree!"<<endl,nname[tt_]="killing spree";
			else if (kil[tt_]==4) cout<<kill<<" is dominating!"<<endl,nname[tt_]="dominating";
			else if (kil[tt_]==5) cout<<kill<<" has a mega kill!"<<endl,nname[tt_]="mega kill";
			else if (kil[tt_]==6) cout<<kill<<" is unstoppable!"<<endl,nname[tt_]="unstoppable";
			else if (kil[tt_]==7) cout<<kill<<" is wicked sick!"<<endl,nname[tt_]="wicked sick";
			else if (kil[tt_]==8) cout<<kill<<" has a monster kill!"<<endl,nname[tt_]="monster kill";
			else if (kil[tt_]==9) cout<<kill<<" is godlike!"<<endl,nname[tt_]="godlike";
			else if (kil[tt_]>=10) cout<<kill<<" is beyond godlike. someone kill him!"<<endl,nname[tt_]="beyond godlike";
			if (lasttime_[tt_]!=-1 && ttime_-lasttime_[tt_]<=10) {
				kil_[tt_]++;
				if (kil_[tt_]==2) cout<<kill<<" just got a Double Kill!"<<endl;
				else if (kil_[tt_]>2) cout<<kill<<" just got a Triple Kill!"<<endl;
				lasttime_[tt_]=ttime_;
			}
			else {
				kil_[tt_]=1;
				lasttime_[tt_]=ttime_;
			}
			int t_=team[name[kill]];
			if (t_!=0) {
				t_--;
				s[t_]++;s[1-t_]=0;
				if (s[0]>=5) puts("The Sentinel is OWNING!");
				else if (s[1]>=5) puts("The Scourge is OWNING!");
			}
		}
		else {
			cout<<kill<<" has killed himself."<<endl;
		}
	}
	return 0;
}
/*
3
YourLittleSiste 0
Ehero 0
Tra 1
21
01:00 Ehero is killed by Tra
02:00 Ehero is killed by Tra
03:00 Ehero is killed by Tra
04:00 Ehero is killed by Tra
04:05 Tra is killed by Roshan
12:00 Tra is killed by Dragon
15:00 Tra is killed by Tra
20:00 Tra is killed by YourLittleSiste
20:01 Tra is killed by YourLittleSiste
20:02 Tra is killed by YourLittleSiste
20:03 Tra is killed by YourLittleSiste
20:04 Tra is killed by YourLittleSiste
25:00 Tra is killed by YourLittleSiste
26:00 Tra is killed by YourLittleSiste
27:00 Tra is killed by YourLittleSiste
28:00 Tra is killed by YourLittleSiste
29:00 Tra is killed by YourLittleSiste
32:00 YourLittleSiste is killed by YourLittleSiste
34:59 YourLittleSiste is killed by Tra
34:59 Tra is killed by YourLittleSiste
35:09 Ehero is killed by Tra

Tra pawned Ehero��s head.
Tra just drew first blood.
Tra pawned Ehero��s head.
Tra pawned Ehero��s head.
Tra is on a killing spree!
Tra pawned Ehero��s head.
Tra is dominating!
Tra has been killed by Roshan.
Tra has been killed by Dragon.
Tra has killed himself.
YourLittleSiste has just ended Tra��s dominating.
YourLittleSiste pawned Tra��s head.
YourLittleSiste just got a Double Kill!
YourLittleSiste pawned Tra��s head.
YourLittleSiste is on a killing spree!
YourLittleSiste just got a Triple Kill!
YourLittleSiste pawned Tra��s head.
YourLittleSiste is dominating!
YourLittleSiste just got a Triple Kill!
YourLittleSiste pawned Tra��s head.
YourLittleSiste has a mega kill!
YourLittleSiste just got a Triple Kill!
The Sentinel is OWNING!
YourLittleSiste pawned Tra��s head.
YourLittleSiste is unstoppable!
The Sentinel is OWNING!
YourLittleSiste pawned Tra��s head.
YourLittleSiste is wicked sick!
The Sentinel is OWNING!
YourLittleSiste pawned Tra��s head.
YourLittleSiste has a monster kill!
The Sentinel is OWNING!
YourLittleSiste pawned Tra��s head.
YourLittleSiste is godlike!
The Sentinel is OWNING!
YourLittleSiste pawned Tra��s head.
YourLittleSiste is beyond godlike. someone kill him!
The Sentinel is OWNING!
YourLittleSiste has killed himself.
Tra has just ended YourLittleSiste��s beyond godlike.
YourLittleSiste pawned Tra��s head.
Tra pawned Ehero��s head.
Tra just got a Double Kill!
*/
