#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;
long long a[2005];
int main ( ) {
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	string s;
	cin>>s;
	long long n,i,j,l=s.length(),r=0;
	cin>>n;
	a[0]=1;
	for (i=1;i<=l;i++) {
		a[i]=a[i-1]*26;
		a[i]%=n;
	}
	for (i=l-1;i>=0;i--) {
		r=r+(s[i]-65)*a[(l-1-i)];
		r%=n;
	}
	if (r==0) {puts("0 0");return 0;}
	for (i=0;i<l-1;i++) {
		for (j=i+1;j<l;j++) {
			long long t1=s[i]-65,t2=s[j]-65,tt1,tt2,tt3,tt4;
			tt1=t1*a[(l-1-i)];tt2=t2*a[(l-1-j)];
			tt3=t2*a[(l-1-i)];tt4=t1*a[(l-1-j)];
			long long t=(tt1+tt2-tt3-tt4+n*1000)%n;
			if (t==r) {cout<<i+1<<' '<<j+1<<endl;return 0;}
		}
	}
	puts("-1 -1");
	return 0;
}
/*
PATCHOULI
16
*/
