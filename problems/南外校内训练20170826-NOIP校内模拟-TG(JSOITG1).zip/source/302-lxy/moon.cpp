# include <iostream>
# include <cstdio>
# include <fstream>
using namespace std;
int a[5000];
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	string s;
	int m,n,i,j,k,f,t;
	long long sum,x;
	cin>>s;
	scanf("%d",&m);
	n=s.length();
	for (i=0;i<n;i++)
		a[i+1]=s[i]-'A';
	x=1;sum=0;
	for (i=n;i>=1;i--)
	{
		sum+=(a[i]*x)%m;
		x=(x*26)%m;
	}
	sum=sum%m;
	if (sum==0) 
	{
		printf("0 0\n");
		return 0;
	}
	if (m==26)
	{
		f=0;k=0;
		for (i=1;i<=n;i++)
			if (a[i]==0) 
			{
				k=i;
				f=1;
				break;
			}
		if (f==1) printf("%d %d\n",k,n);
		else printf("-1 -1\n");
		return 0;
	}
	for (i=1;i<=n;i++)
		for (j=i+1;j<=n;j++)
		{
			if (a[i]==a[j]) continue;
			swap(a[i],a[j]);
			x=1;sum=0;
			for (k=n;k>=1;k--)
			{
				sum=(sum+a[k]*x)%m;
				x=(x*26)%m;
			}
			sum=sum%m;
			swap(a[j],a[i]);
			if (sum==0) 
			{
				printf("%d %d\n",i,j);
				return 0;
			}
		}
	printf("-1 -1\n");
	return 0;
}
