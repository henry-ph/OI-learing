# include <iostream>
# include <cstdio>
# include <fstream>
# include <algorithm>
using namespace std;
int b[20000],vis[20000];
struct node
{
	int x,y,w;
}a[60000];
bool cmp(node p,node q)
{
	return p.w<q.w;
}
int fi(int x)
{
	if (x!=b[x]) b[x]=fi(b[x]);
	return b[x];
}
int main()
{
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	int n,m,r,i,xx,yy,zz,ans,t1,t2;
	scanf("%d%d%d",&n,&m,&r);
	for (i=1;i<=r;i++)
	{
		scanf("%d%d%d",&xx,&yy,&zz);
		xx++;yy++;
		a[i].x=xx;a[i].y=yy+n;a[i].w=10000-zz;
	}
	sort(a+1,a+1+r,cmp);
	for (i=1;i<=n+m;i++)
	{
		b[i]=i;
		vis[i]=0;
	}
	ans=0;
	for (i=1;i<=r;i++)
	{
		xx=a[i].x;yy=a[i].y;
		t1=fi(xx);t2=fi(yy);
		if (t1!=t2)
		{
			b[t1]=t2;
			ans+=a[i].w;
		}
	}
	for (i=1;i<=n+m;i++)
		vis[fi(i)]=1;
	for (i=1;i<=n+m;i++)
		if (vis[i]) ans+=10000;
	printf("%d\n",ans);
	return 0;
}
