#include<iostream>
#include<cstdio>
#include<fstream>
#include<cstring>
#include<cstdlib>
using namespace std;
string s;
int m;
int pw[2010],hs[2010];
int gtHash(int l,int r)
{
	return (int)(hs[r]+m-1LL*pw[r-l+1]*hs[l-1]%(long long)m)%m;
}
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>s;
	scanf("%d",&m);
	int l=s.size();
	pw[0]=1;
	for(int i=1;i<=l;i++)
	{
		pw[i]=pw[i-1]*26%m;
		hs[i]=(hs[i-1]*26+(s[i-1]-'A'))%m;
	}
	if(hs[l]==0)
	{
		printf("0 0");
		return 0;
	}
	for(int i=1;i<l;i++)
	{
		for(int j=i+1;j<=l;j++)
		{
			int res=gtHash(1,i-1)*pw[l-i+1]%m;
			res=res+(s[j-1]-'A')*pw[l-i]%m;
			if(res>=m)res-=m;
			res=res+gtHash(i+1,j-1)*pw[l-j+1]%m;
			if(res>=m)res-=m;
			res=res+(s[i-1]-'A')*pw[l-j]%m;
			if(res>=m)res-=m;
			res=res+gtHash(j+1,l);
			if(res>=m)res-=m;
			if(!res)
			{
				printf("%d %d",i,j);
				return 0;
			}
		}
	}
	printf("-1 -1");
	return 0;
}
