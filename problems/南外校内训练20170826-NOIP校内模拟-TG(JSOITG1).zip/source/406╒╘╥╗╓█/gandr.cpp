#include<iostream>
#include<cstdio>
#include<map>
#include<fstream>
using namespace std;
int m,n,r;
int ans;
map<pair<int,int> ,int>mp;
int main()
{
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	scanf("%d%d%d",&m,&n,&r);
	ans=(m+n)*10000;
	for(int i=1;i<=r;i++)
	{
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		if(mp[make_pair(x,y)]<z)
		{
			ans=ans+mp[make_pair(x,y)]-z;
			mp[make_pair(x,y)]=z;
		}
	}
	printf("%d",ans);
	return 0;
}
