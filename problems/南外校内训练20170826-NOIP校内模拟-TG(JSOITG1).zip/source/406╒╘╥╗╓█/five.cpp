#include<iostream>
#include<cstdio>
#include<fstream>
#include<cstring>
#include<map>
using namespace std;
int n,m;
bool fst;
int f[20010];
int lst[20010];
int cos[20010];
int gr[2];
int s[20010];
map<string,int>mp;
string hon[11]={"","","","killing spree","dominating","mega kill","unstoppable","wicked sick","monster kill","godlike","beyond godlike"};
string kll[11]={"","","",
                " is on a killing spree!",
                " is dominating!",
                " has a mega kill!",
                " is unstoppable!",
                " is wicked sick!",
                " has a monster kill!",
                " is godlike!",
                " is beyond godlike. someone kill him!"};
int main()
{
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		lst[i]=-10000;
		string str;
		int x;
		cin>>str;
		scanf("%d",f+i);
		mp[str]=i;
	}
	scanf("%d",&m);
	while(m--)
	{
		string s1,s2,t,o1,o2,o3;
		cin>>t>>s1>>o1>>o2>>o3>>s2;
		int tm=((t[0]-'0')*10+t[1]-'0')*60+((t[3]-'0')*10+t[4]-'0');
		int p1=mp[s1],p2=mp[s2];
		if(!p2)
		{
			cout<<s1;
			printf(" has been killed by ");
			cout<<s2;
			printf(".\n");
			continue;
		}
		if(p1==p2)
		{
			cout<<s1;
			printf(" has killed himself.\n");
			continue;
		}
		if(s[p1]>=3)
		{
			cout<<s2;
			printf(" has just ended ");
			cout<<s1;
			printf("\'s ");
			cout<<hon[s[p1]];
			printf(".\n");
		}
		else
		{
			cout<<s2;
			printf(" pawned ");
			cout<<s1;
			printf("\'s head.\n");
			if(!fst)
			{
				cout<<s2;
				printf(" just drew first blood.\n");
				fst=true;
			}
		}
		s[p1]=0;
		gr[f[p1]]=0;
		s[p2]++;
		gr[f[p2]]++;
		if(s[p2]>10)s[p2]=10;
		if(s[p2]>=3)
		{
			cout<<s2<<kll[s[p2]];
			puts("");
		}
		if(lst[p2]+10>=tm)
		{
			cos[p2]++;
			cout<<s2;
			printf(" just got a ");
			if(cos[p2]==2)
			{
				printf("Double");
			}
			else printf("Triple");
			printf(" Kill!\n");
		}
		else cos[p2]=1;
		lst[p2]=tm;
		if(gr[f[p2]]>=5)
		{
			printf("The ");
			if(f[p2])printf("Scourage");else printf("Sentinel");
			printf(" is OWNING!\n");
		}
	}
	return 0;
}
