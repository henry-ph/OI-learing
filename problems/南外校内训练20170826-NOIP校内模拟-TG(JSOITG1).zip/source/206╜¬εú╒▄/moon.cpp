#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	
	long long a=0;
	string s;
	cin>>s;
	int m;
	cin>>m;
	
	if(s.size()>10){
		cout<<"-1 -1"<<endl;
		return 0;
	}
	else{
		for(int i=0;i<s.size();i++){
			for(int j=0;j<s.size();j++){
				int x=1;
				for(int k=s.size()-1;k>=0;k--){
					a+=s[k]*=x;
					x*=26;
				}
				if(a%m==0){
					if(i==j){
						cout<<"0 0";
						return 0;
					}
					else{
						cout<<i+1<<' '<<j+1;
						return 0;
					}
				}
			}
		}
	}
}
