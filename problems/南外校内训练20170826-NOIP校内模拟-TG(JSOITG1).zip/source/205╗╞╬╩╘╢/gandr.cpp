#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
using namespace std;
int n, m, r, f[200005], used[200005], sum;
pair <int, int> a[200005];
vector <pair<int, int> > v[200005];
int main() {
	/*
	freopen("gandr.in", "r", stdin);
	freopen("gandr.out", "w", stdout);
	*/
	cin >> n >> m >> r;
	for (int i = 0; i < n + m; i ++)
		a[i] = make_pair(0, i);
	for (int i = 1; i <= r; i ++) {
		int x, y, z;
		cin >> x >> y >> z;
		a[x].first = max(a[x].first, z);
		a[y + n].first = max(a[y + n].first, z);
		v[x].push_back(make_pair(z, y));
		v[y].push_back(make_pair(z, x));
	}
	sort(a, a + n + m);
	for (int i = 0; i < n + m; i ++) {
		int x = a[i].second, mx = -1;
		used[x] = 1;
		for (int j = 0; j < v[x].size(); j ++) {
			if (used[v[x][j].second] == 1)
				mx = max(mx, v[x][j].first);
		}
		sum += mx;
	}
	cout << 100000 - sum << endl;
	return 0;
}
