#include <iostream>
#include <cstdio>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <cmath>
using namespace std;
string s;
int m;
long long num;

long long power(int i,int j) {
	long long a=i;
	for (int k=1; k<j; ++k)a*=i;
	return a;
}

int main() {
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	cin>>s;
	scanf("%d",&m);
	if (s.size()<=10) {
		for (int i=s.size()-1; i>=0; --i) {
			num+=pow(26,s.size()-1-i)*(s[i]-'A');
			//	cout<<num<<endl;
		}
		if (num%m==0) {
			cout<<"0 0\n";
			return 0;
		}
		for (int i=0; i<s.size(); ++i) {
			for (int j=i+1; j<s.size(); ++j) {
				num=0;
				//cout<<i<<" "<<j<<" ";
				swap(s[i],s[j]);
				for (int k=s.size()-1; k>=0; --k) {
					num+=pow(26,s.size()-1-k)*(s[k]-'A');
				}
				//	cout<<num<<endl;
				if (num%m==0) {
					cout<<i+1<<" "<<j+1<<endl;
					return 0;
				}
				swap(s[i],s[j]);
			}
		}
		puts("-1 -1");
		return 0;
	} else if (m==5 || m==25) {
		int num=0;
		for(int i=0; i<s.size(); ++i) {
			num+=(s[i]-'A')*26;
			num%=100;
		}
		if(num%m==0) {
			puts("0 0");
			return 0;
		}
		for (int i=0; i<s.size(); ++i) {
			for (int j=i+1; j<s.size(); ++j) {
				num=0;
				swap(s[i],s[j]);
				for (int k=0; k<s.size(); ++k) {
					num+=(s[k]-'A')*26;
					num%=100;
				}
				if (num%m==0) {
					cout<<i+1<<" "<<j+1<<endl;
					return 0;
				}
			}
		}
		puts("-1 -1");
		return 0;
	}
	return 0;
}
