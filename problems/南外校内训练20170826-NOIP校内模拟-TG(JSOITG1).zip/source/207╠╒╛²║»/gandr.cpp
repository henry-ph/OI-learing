#include <iostream>
#include <cstdio>
#include <string>
#include <cstdlib>
#include <algoerithm>
#include <cmath>
using namespace std;
int main(){
	
	return 0;
}
