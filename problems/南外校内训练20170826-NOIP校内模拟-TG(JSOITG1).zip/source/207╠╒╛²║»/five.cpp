#include <iostream>
#include <cstdio>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <set>
#include <cmath>
#include <map>
using namespace std;
const int maxn=20005;
const int inf=0x3f3f3f3f;
struct Node {
	int ls,ds,lstm,lsts;
} cnt[maxn];
map<string,int> ind;
map<string,int> inc;
string bklsch[11]= {"","","","killing spree","dominating","mega kill","unstoppable","wicked sick","monster kill","godlike","beyond godlike"};
string lsch[11]= {"","","","is on a killing spree","is domninating","has a mega kill","is unstoppable","is wicked sick","has a monster kill","is godlike","is beyond a godlike. someone kill him"};
string dsch[4]= {"","","just got a Double Kill","just got a Triple Kill"};
string dm[2]={"The Sentinel is OWNING","The Scourge is OWNING"};
set<string> stt;
int ct[2];
bool first_blood;
string kl,bkl;
int n,k;
bool get_sec(int m1,int s1,int m2,int s2) {
	if (m2-m1>1)return 0;
	if (m1==m2) {
		if (s2-s1<=10)return 1;
		return 0;
	}
	if (s2+60-s1<=10)return 1;
	return 0;
}
int main() {
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	scanf("%d",&n);
	for (int i=0;i<n+100;++i)cnt[i].lstm=-inf;
	for (int i=0; i!=n; ++i) {
		cin>>kl>>k;
		ind[kl]=k;
		inc[kl]=i;
		stt.insert(kl);
	}
	scanf("%d",&k);
	while (k--) {
	//	cout<<k<<endl;
		int m,s;
		scanf("%d:%d",&m,&s);
		cin>>bkl>>kl>>kl>>kl>>kl;
		if (stt.find(kl)==stt.end()) {
			cout<<bkl;
			printf(" has been killed by ");
			cout<<kl<<"."<<endl;
			continue;
		}
		if (bkl==kl) {
			cout<<kl;
			printf(" has killed himself.\n");
			continue;
		}
		if (cnt[inc[bkl]].ls>2) {
			if (cnt[inc[bkl]].ls<11)cout<<kl<<" has just ended "<<bkl<<"'s "<<bklsch[cnt[inc[bkl]].ls]<<".\n";
			else cout<<kl<<" has just ended "<<bkl<<"'s"<<bklsch[10]<<".\n";
		} else {
			cout<<kl<<" pawned "<<bkl<<"'s head.\n";
		}
		ct[ind[bkl]]=0;
		ct[ind[kl]]++;
		
		cnt[inc[kl]].ls++;
		cnt[inc[bkl]].ls=0;
//		cout<<cnt[inc[kl]].ls<<" "<<cnt[inc[bkl]].ls<<endl;
		if (!first_blood) {
			cout<<kl<<" just drew first blood.\n";
			first_blood=1;
		}
		if (cnt[inc[kl]].ls>2) {
			if (cnt[inc[kl]].ls<11)cout<<kl<<" "<<lsch[cnt[inc[kl]].ls]<<"!"<<endl;
			else cout<<kl<<" "<<lsch[10]<<"!"<<endl;
		}
		if (get_sec(cnt[inc[kl]].lstm,cnt[inc[kl]].lsts,m,s)) {
			if (cnt[inc[kl]].ds<3)cnt[inc[kl]].ds++;
			cout<<kl<<" "<<dsch[cnt[inc[kl]].ds]<<"!\n";
		}
		if (!cnt[inc[kl]].ds)cnt[inc[kl]].ds++;
		cnt[inc[kl]].lstm=m;
		cnt[inc[kl]].lsts=s;
	//	cout<<ct[0]<<" "<<ct[1]<<endl;
		if (ct[0]>=5){
			cout<<dm[0]<<"!\n";
		}else if (ct[1]>=5){
			cout<<dm[1]<<"!\n";
		}
	}
	return 0;
}
