#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<deque>
#include<string>
#include<string.h>
#include<vector>
#include<stack>
#include<queue>
#include<math.h>
#include<stdlib.h>
#include<map>
#include<set>
#include<time.h>
#include<list>
const int INF=2e9;
using namespace std;
const int ini=1e4;
const int MX=2e4+20;
priority_queue<pair<int,pair<int,int> > > edg;
int fa[MX],ans;
int sfind(int x){
	if (x==fa[x]) return x; else return fa[x]=sfind(fa[x]);
}
int main(){
	freopen("gandr.in","r",stdin);
	freopen("gandr.out","w",stdout);
	int m,n,r;
	scanf("%d%d%d",&m,&n,&r);
	for (int i=0;i<r;i++)
	{
		int x,y,d;
		scanf("%d%d%d",&x,&y,&d);
		x++;y=y+m+1;
		edg.push(make_pair(d-ini,make_pair(x,y)));
	}
	for (int i=1;i<=n+m;i++){
		edg.push(make_pair(-ini,make_pair(0,i)));
		fa[i]=i;
	}
	while (!edg.empty())
	{
		pair<int,pair<int,int> > t=edg.top(); edg.pop();
		int vl=-t.first,x=t.second.first,y=t.second.second,fx=sfind(x),fy=sfind(y);
		if (fx!=fy){
			ans+=vl;
			fa[fx]=fy;
		}
	}
	printf("%d\n",ans);
	return 0;
}
