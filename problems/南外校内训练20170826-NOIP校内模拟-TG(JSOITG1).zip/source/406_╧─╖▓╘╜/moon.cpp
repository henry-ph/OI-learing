#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<deque>
#include<string>
#include<string.h>
#include<vector>
#include<stack>
#include<queue>
#include<math.h>
#include<stdlib.h>
#include<map>
#include<set>
#include<time.h>
#include<list>
const int INF=2e9;
using namespace std;
long long ans,t;
int ys[2010];
int main(){
	freopen("moon.in","r",stdin);
	freopen("moon.out","w",stdout);
	string L;int M;
	cin>>L>>M;
	ys[L.size()-1]=1;
	for (int i=L.size()-1;i>=0;i--)
	{
		if (i!=L.size()-1) ys[i]=ys[i+1]*26%M;
		ans+=(L[i]-'A')*ys[i];
	}
	if (ans%M==0) {
		cout<<"0 0"<<endl;
		return 0;
	}
	for (int i=0;i<L.size();i++)
	for (int j=i+1;j<L.size();j++)
	{
		t=ans;
		t-=(L[i]-'A')*ys[i];
		t-=(L[j]-'A')*ys[j];
		t+=(L[i]-'A')*ys[j];
		t+=(L[j]-'A')*ys[i];
		if (t%M==0){
			cout<<i+1<<' '<<j+1<<endl;
			return 0;
		}
	}
	cout<<"-1 -1"<<endl;
	return 0;
}
