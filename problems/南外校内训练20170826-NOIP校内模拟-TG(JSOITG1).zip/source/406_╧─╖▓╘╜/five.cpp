#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<deque>
#include<string>
#include<string.h>
#include<vector>
#include<stack>
#include<queue>
#include<math.h>
#include<stdlib.h>
#include<map>
#include<set>
#include<time.h>
#include<list>
const int INF=2e9;
using namespace std;
map<string,int> mp;
struct lss{
	int stt,nm;
};
map<string,lss> ls;
struct dss{
	int stt,edt,nm;
};
map<string,dss> ds;
map<int,string> zyy;
const int MX=50020;
string ls1[MX],lsc[MX],ds1[MX];
int zy[2];
int main(){
	freopen("five.in","r",stdin);
	freopen("five.out","w",stdout);
	zyy[0]="The Sentinel is OWNING!";
	zyy[1]="The Scourge is OWNING!";
	ls1[3]=" is on a killing spree!";
	ls1[4]=" is dominating!";
	ls1[5]=" has a mega kill!";
	ls1[6]=" is unstoppable!";
	ls1[7]=" is wicked sick!";
	ls1[8]=" has a monster kill!";
	ls1[9]=" is godlike!";
	for (int i=10;i<MX;i++) ls1[i]=" is beyond godlike. someone kill him!";
	lsc[3]="killing spree!";
	lsc[4]="dominating!";
	lsc[5]="mega kill!";
	lsc[6]="unstoppable!";
	lsc[7]="wicked sick!";
	lsc[8]="monster kill!";
	lsc[9]="godlike!";
	for (int i=10;i<MX;i++) lsc[i]="beyond godlike";
	ds1[2]=" just got a Double Kill!";
	for (int i=3;i<MX;i++) ds1[i]="  just got a Triple Kill!";
	int N,M,fr=0;
	scanf("%d",&N);
	for (int i=0;i<N;i++)
	{
		string x;int y;cin>>x>>y;
		mp[x]=y+1;
	}
	scanf("%d",&M);
	for (int i=0;i<M;i++)
	{
		string t;string x,y;
		cin>>t>>x>>y>>y>>y>>y;
		swap(x,y);
		int tm=((t[0]-'0')*10+(t[1]-'0'))*60+((t[3]-'0')*10+(t[4]-'0'));
		if (x==y)
		{
			cout<<x<<" has killed himself."<<endl;
		}
		else if (mp[x]==0||mp[x]==mp[y])
		{
			cout<<y<<" has been killed by "<<x<<'.'<<endl;
		}
		else
		{
			if (ls[y].nm<3) cout<<x<<" pawned "<<y<<"'s head."<<endl;
			zy[mp[y]]=tm; ls[y].stt=0;
			if (!fr) fr=1,cout<<x<<" just drew first blood."<<endl;
			if (ls[y].nm>=3) cout<<x<<" has just ended "<<y<<"'s "<<lsc[ls[y].nm]<<endl;
			ls[x].nm++;
			if (ls[x].stt==0) ls[x].stt=tm;
			if (ls[x].nm>=3) cout<<x<<ls1[ls[x].nm]<<endl;
			dss d=ds[x]; if (d.stt==0) d.stt=tm,d.edt=tm,d.nm=1;
			else if (tm-d.edt<=10) ds[x].nm++,ds[x].edt=tm; else ds[x].nm=1,ds[x].stt=ds[x].edt=tm;
			if (ds[x].nm>=2) cout<<x<<ds1[ds[x].nm]<<endl;
			if (ls[x].nm>=5&&zy[mp[x]]<ls[x].stt) cout<<zyy[mp[x]]<<endl;
		}
	}
	return 0;
}
