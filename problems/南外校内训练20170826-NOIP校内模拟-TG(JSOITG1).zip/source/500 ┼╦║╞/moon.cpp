#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N = 2005;
char s[N];
int num[N], n;

long long _pow(int x, int i) {
	long long ans = 1;
	for (int j = 1; j <= i; ++j) {
		ans*= x;
		ans %= n;
	}
	return ans;
}
long long change(int i, int x) {
	return i * _pow(26, x);
}
int main(){
	freopen("moon.in", "r", stdin);
	freopen("moon.out", "w", stdout);
	scanf("%s%d", s, &n);
	int len = strlen(s), str = len;
	for (int i = 0; i < len; ++i) {
		if (!i && s[i] == 'A') {
			str--;
			continue;
		}
		num[i] = s[i] - 'A';
	}
	long long sum = 0;
	for (int i = str - 1; i >= 0; --i) sum += change(num[str - i - 1], i);
	if (!(sum % n)) {
		printf("0 0\n");
		return 0;
	}
	for (int i = 0; i < str; ++i) {
		for (int j = i + 1; j < str; ++j) {
			swap(num[i], num[j]);
			sum = 0;
			for (int u = str - 1; u >= 0; --u) sum += change(num[str - u - 1], u);
			if (!(sum % n)) {
				printf("%d %d\n", i + 1, j + 1);
				return 0;
			}
			else swap(num[i], num[j]);
		}
	}
	printf("-1 -1\n");
	return 0;
}
