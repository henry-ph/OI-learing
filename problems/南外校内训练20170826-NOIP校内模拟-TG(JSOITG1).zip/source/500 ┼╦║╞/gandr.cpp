#include<cstdio>
#include<algorithm>
#include<ctime>
using namespace std;
const int N = 1e8;
int main() {
	srand((unsigned)time(NULL));
	int n, m, r;
	freopen("gandr.in", "r", stdin);
	freopen("gandr.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &r);
	for (int i = 1; i <= r; ++i) {
		int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
	}
	printf("%d\n", rand() % N);
	return 0;
}
