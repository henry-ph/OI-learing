#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<map>
#include<utility>
using namespace std;
const int N = 2e4 + 5;
map<string, int> G, H;
int f[N], Count[N], combo[N];
bool own[2];
pair<int, int> kill[N];

void honor(int x, string b) {
	switch (x) {
		case 3: {
			cout << b << " is on a killing spree!" << endl;
			break;
			}
		case 4: {
			cout << b << " is dominating!" << endl;
			break;
		}
		case 5: {
			cout << b << " has a mega kill!" << endl;
			break;
		}
		case 6: {
			cout << b << " is unstoppable!" << endl;
			break;
		}
		case 7: {
			cout << b << " is wicked sick!" << endl;
			break;
		}
		case 8: {
			cout << b << " has a monster kill!" << endl;
			break;
		}
		case 9: {
			cout << b << " is godlike!" << endl;
			break;
		}
	}
	if (x >= 10) cout << b << " is beyond godlike. someone kill him!" << endl;
}
int main() {
	int n, m;
	freopen("five.in", "r", stdin);
	freopen("five.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		string s;
		int opr;
		cin >> s >> opr;
		G.insert(make_pair(s, i)); 
		f[i] = opr;
	}
	scanf("%d", &m);
	for (int i = 1; i <= m; ++i) {
		string time, a, w1, w2, w3, b;
		cin >> time >> a >> w1 >> w2 >> w3 >> b;
		if (a == b) {
			cout << a << " has killed himself." << endl;
			continue;
		}
		else if (!G.count(b)) {
			cout << a << " has been killed by " << b << "." << endl;
			continue;
		}
		if (!own[f[G[b]]]) own[f[G[b]]] = true;
		if (own[f[G[a]]]) own[f[G[a]]] = false;
		Count[G[b]]++;
		bool flag = false;
		if (Count[G[a]] >= 3) {
			flag = true;
			cout << b << " has just ended " << a << "'s" << " ";
			switch (Count[G[a]]) {
				case 3: {
					cout << "killing spree." << endl;
					break;
					}
				case 4: {
					cout << "dominating." << endl;
					break;
				}
				case 5: {
					cout << "mega kill." << endl;
					break;
				}
				case 6: {
					cout << b << "is unstoppable!" << endl;
					break;
				}
				case 7: {
					cout << "wicked sick." << endl;
					break;
				}
				case 8: {
					cout << "monster kill." << endl;
					break;
				}
				case 9: {
					cout << "godlike." << endl;
					break;
				}
			}
			if (Count[G[a]] >= 10) cout << "beyond godlike." << endl;
		}
		if (!flag) cout << b << " pawned " << a << "'s head." << endl;
		if (i == 1) cout << b << " just drew first blood." << endl;
		Count[G[a]] = 0;
		honor(Count[G[b]], b);
		int tim;
		tim = ((time[0] - '0') * 10 + time[1] - '0') * 60 + ((time[3] - '0') * 10 + time[4] - '0');
		combo[G[b]] = 1;
		if (tim - kill[G[b]].second <= 10) {
			combo[G[b]] += kill[G[b]].first;
			if (combo[G[b]] == 2) cout << b << " just got a Double Kill!" << endl;
			if (combo[G[b]] >= 3) cout << b << " just got a Triple Kill!" << endl;
		}
		else combo[G[b]] = 1;
		kill[G[b]] = make_pair(combo[G[b]], tim);
		if (own[f[G[b]]] && Count[G[b]] >= 5) {
			if (!f[G[b]]) cout << "The Sentinel is OWNING!" << endl;
			else cout << "The Scourge is OWNING!" << endl;
		}
	}
	return 0;
}
